TabbedClient — Hordozható Linux Csomag
=======================================

Indítás közvetlenül hordozhatóként:
    ./tabbedclient

Tálcára kitűzés és menüintegráció (Zorin OS / Ubuntu / GNOME / KDE):
    ./install_desktop_entry.sh
    (Ez azonnal regisztrálja a Bento ikont az asztali környezetben és lehetővé teszi a jobb-klikkes 'Kitűzés a tálcára' opciót.)

Rendszerkövetelmények (Debian / Ubuntu / Zorin OS / Mint):
    sudo apt install python3-gi gir1.2-gtk-3.0 gir1.2-webkit2-4.1 gir1.2-ayatanaappindicator3-0.1
