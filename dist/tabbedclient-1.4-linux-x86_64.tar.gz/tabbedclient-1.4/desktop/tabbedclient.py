#!/usr/bin/env python3
"""
TabbedClient — Natív Linux GTK3 + WebKitGTK Multi-Tab Kliens
Zero-Telemetry, Teljes Munkamenet-Izoláció (Multi-Account)
"""

import atexit
import base64
import io
import json
import mimetypes
import os
import re
import socket
import subprocess
import sys
import urllib.parse
import uuid

# Dual-GPU / Linux WebKit2GTK 2.42+ DMA-BUF inicializációs késleltetés megelőzése
os.environ.setdefault("WEBKIT_DISABLE_DMABUF_RENDERER", "1")

import gi

gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
gi.require_version('Gio', '2.0')
try:
    gi.require_version('WebKit2', '4.1')
except ValueError:
    gi.require_version('WebKit2', '4.0')

try:
    gi.require_version('AyatanaAppIndicator3', '0.1')
    from gi.repository import AyatanaAppIndicator3 as AppIndicator
except Exception:
    try:
        gi.require_version('AppIndicator3', '0.1')
        from gi.repository import AppIndicator3 as AppIndicator
    except Exception:
        AppIndicator = None

try:
    gi.require_version('Notify', '0.7')
    from gi.repository import Notify
except Exception:
    Notify = None

from gi.repository import Gtk, WebKit2, Gdk, GLib, GdkPixbuf, Gio

# GTK / X11 / Wayland folyamatazonosítás és tálca-illeszkedés biztosítása
GLib.set_prgname("tabbedclient")
GLib.set_application_name("TabbedClient")

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC_DIR = os.path.join(BASE_DIR, "src")
TEMPLATE_CONFIG_PATH = os.path.join(BASE_DIR, "data", "config.json")
if not os.path.exists(TEMPLATE_CONFIG_PATH):
    TEMPLATE_CONFIG_PATH = os.path.join(BASE_DIR, "data", "config.json.template")


def _resolve_paths():
    """
    Meghatározza a konfiguráció, adatprofilok és gyorsítótár elérési útvonalait.
    - Rendszerszintű telepítés (/usr, /opt) esetén szabványos XDG könyvtárakat használ
      (~/.config/tabbedclient és ~/.local/share/tabbedclient), így sosem lép fel jogosultsági hiba (PermissionError).
    - Hordozható (Portable) vagy fejlesztői környezetben, ha a helyi ./data mappa írható,
      akkor a helyi adatkönyvtárat használja.
    """
    is_system_install = BASE_DIR.startswith("/usr") or BASE_DIR.startswith("/opt")
    local_data = os.path.join(BASE_DIR, "data")

    if not is_system_install and os.path.exists(local_data) and os.access(local_data, os.W_OK):
        data_dir = local_data
        config_path = os.path.join(data_dir, "config.json")
        profiles_dir = os.path.join(data_dir, "profiles")
    else:
        xdg_config = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
        xdg_data = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
        
        config_dir = os.path.join(xdg_config, "tabbedclient")
        data_dir = os.path.join(xdg_data, "tabbedclient")
        profiles_dir = os.path.join(data_dir, "profiles")
        config_path = os.path.join(config_dir, "config.json")

    return data_dir, config_path, profiles_dir


DATA_DIR, CONFIG_PATH, PROFILES_DIR = _resolve_paths()

try:
    os.makedirs(PROFILES_DIR, exist_ok=True)
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
except Exception:
    pass

APP_VERSION = "1.4"
INSTANCE_SOCKET_NAME = "tabbedclient.sock"


def get_instance_socket_path() -> str:
    runtime_dir = os.environ.get("XDG_RUNTIME_DIR")
    if not runtime_dir or not os.path.exists(runtime_dir):
        xdg_config = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
        runtime_dir = os.path.join(xdg_config, "tabbedclient")
    try:
        os.makedirs(runtime_dir, exist_ok=True)
    except Exception:
        pass
    return os.path.join(runtime_dir, INSTANCE_SOCKET_NAME)


def try_activate_existing_instance() -> bool:
    """
    Megpróbálja elérni a már futó példányt és előtérbe hozni azt.
    Ha a futó példány régebbi verzió, jelzést küldünk neki a leállásra,
    és az új példány átveszi a helyét (False-szal térünk vissza).
    Ha azonos verzió fut, True-val térünk vissza (az új folyamat kilép).
    Ha nem fut példány, False-szal tér vissza.
    """
    import time
    sock_path = get_instance_socket_path()
    if not os.path.exists(sock_path):
        return False

    try:
        client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        client.settimeout(1.5)
        client.connect(sock_path)
        client.sendall(f"ACTIVATE {APP_VERSION}\n".encode("utf-8"))
        try:
            resp = client.recv(1024).decode("utf-8", errors="ignore").strip()
        except Exception:
            resp = "OK"
        client.close()

        if resp == "REPLACE":
            time.sleep(0.5)
            try:
                if os.path.exists(sock_path):
                    os.unlink(sock_path)
            except Exception:
                pass
            return False

        return True
    except (ConnectionRefusedError, FileNotFoundError, socket.timeout):
        try:
            if os.path.exists(sock_path):
                os.unlink(sock_path)
        except Exception:
            pass
        return False
    except Exception as err:
        print(f"[SingleInstance Connect Warning] {err}", file=sys.stderr)
        return False


def setup_single_instance_server(activate_callback, quit_callback=None):
    """
    Létrehozza a helyi Unix domain socket szervert az egypéldányos futáshoz.
    GLib IO watch segítségével eseményvezérelten figyeli a bejövő aktiválási kéréseket.
    Ha újabb / eltérő verzió próbál indulni, a futó példány átadja a helyét.
    """
    sock_path = get_instance_socket_path()
    try:
        if os.path.exists(sock_path):
            try:
                os.unlink(sock_path)
            except Exception:
                pass

        server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        server.bind(sock_path)
        server.listen(5)
        server.setblocking(False)

        def _on_socket_activity(source, condition):
            try:
                conn, _ = server.accept()
                raw = conn.recv(1024).decode("utf-8", errors="ignore")
                parts = raw.strip().split()
                cmd = parts[0] if parts else ""
                incoming_ver = parts[1] if len(parts) > 1 else ""

                if incoming_ver and incoming_ver != APP_VERSION and quit_callback:
                    try:
                        conn.sendall(b"REPLACE\n")
                        conn.close()
                    except Exception:
                        pass
                    GLib.idle_add(quit_callback)
                    return True

                try:
                    conn.sendall(b"OK\n")
                    conn.close()
                except Exception:
                    pass

                if "ACTIVATE" in cmd:
                    GLib.idle_add(activate_callback)
            except Exception:
                pass
            return True

        GLib.io_add_watch(server.fileno(), GLib.PRIORITY_DEFAULT, GLib.IOCondition.IN, _on_socket_activity)

        def _cleanup():
            try:
                server.close()
                if os.path.exists(sock_path):
                    os.unlink(sock_path)
            except Exception:
                pass
        atexit.register(_cleanup)

        return server
    except Exception as err:
        print(f"[SingleInstance Server Error] {err}", file=sys.stderr)
        return None

VALID_THEMES = ["slate", "nordic", "jetbrains", "solarized", "enterprise"]
SIDEBAR_EXPANDED_WIDTH = 220
SIDEBAR_COLLAPSED_WIDTH = 48

DEFAULT_CONFIG = {
    "version": APP_VERSION,
    "theme": "slate",
    "sidebarCollapsed": False,
    "activeTabId": None,
    "settings": {
        "theme": "slate",
        "sidebarCollapsed": False,
        "minimizeToTrayOnClose": True,
        "startMinimized": False,
        "hardwareAcceleration": True
    },
    "profiles": [
        {"id": "default", "name": "Alapértelmezett", "color": "#94a3b8"},
        {"id": "work", "name": "Munkahelyi", "color": "#388bfd"},
        {"id": "personal", "name": "Magán", "color": "#2ea043"}
    ],
    "tabs": []
}


def _default_favicon_url(url: str) -> str:
    try:
        parts = urllib.parse.urlsplit(url or "")
        if parts.scheme and parts.netloc:
            return f"{parts.scheme}://{parts.netloc}/favicon.ico"
    except Exception:
        pass
    return ""


def resolve_service_icon(title: str, url: str, explicit_icon: str = "") -> str:
    """
    Meghatározza a fül hivatalos szolgáltatás-ikonját.
    Ismert szolgáltatásoknál (Gmail, Naptár, Messenger, WhatsApp, Telegram stb.)
    garantálja a beépített vektoros ikont, megelőzve a dinamikus weboldal-faviconok
    (pl. Gmail rárajzolt unreadCountja vagy a Naptár napi dátuma) általi torzulást.
    """
    combined = f"{title or ''} {url or ''}".lower()
    if "gmail" in combined or "mail.google" in combined:
        return "gmail"
    if "calendar.google" in combined or "naptár" in combined or "naptar" in combined:
        return "calendar"
    if "messenger" in combined or "m.me" in combined:
        return "messenger"
    if "whatsapp" in combined:
        return "whatsapp"
    if "telegram" in combined or "t.me" in combined:
        return "telegram"
    if "slack" in combined:
        return "slack"
    if "teams" in combined:
        return "teams"
    if "discord" in combined:
        return "discord"
    if "notion" in combined:
        return "notion"
    if "trello" in combined:
        return "trello"
    if "mail" in combined or "posta" in combined or "outlook" in combined or "proton" in combined:
        return "mail"
    if explicit_icon and explicit_icon != "globe":
        return explicit_icon
    return "globe"


def extract_unread_count(title: str, url: str = "") -> int:
    """
    Kinyeri a valós olvasatlan értesítések / üzenetek számát a böngészőfül címéből.
    Kizárólag megbízható mintákra támaszkodik a hamis pozitívok (pl. levél tárgyában
    vagy dátumban szereplő zárójeles számok, naptári dátumok) elkerülése érdekében.
    """
    if not title:
        return 0

    clean = title.strip()
    low_url = (url or "").lower()
    low_title = clean.lower()

    # A Google Naptárnak nincs olvasatlan levél/üzenetszámlálója; a dátumokat (pl. '30') tilos számlálónak tekinteni
    if "calendar.google" in low_url or "naptár" in low_title or "calendar" in low_title:
        return 0

    # 1. Cím legelején lévő zárójeles szám: pl. '(3) Gmail', '[2] Slack', '*(1) Chat', '(99+) WhatsApp'
    m = re.match(r'^(?:\*\s*)?[\(\[]([0-9]+)\+?[\)\]]', clean)
    if m:
        try:
            val = int(m.group(1))
            return val if 0 < val <= 9999 else 0
        except ValueError:
            pass

    # 2. Levelező/üzenetküldő mappa vagy szolgáltatás neve utáni zárójeles szám:
    # Pl. 'Gmail — Beérkező levelek (12)', 'Beérkező levelek (3) - Gmail', 'Inbox (5) - Work Mail', 'Beérkezett üzenetek (2)'
    m = re.search(
        r'(?:^|[\s—–\-])(?:Inbox|Beérkező levelek|Beérkezett üzenetek|Messages|Üzenetek|Chats|Csevegések)\s*[\(\[]([0-9]+)\+?[\)\]]',
        clean,
        re.IGNORECASE,
    )
    if m:
        try:
            val = int(m.group(1))
            return val if 0 < val <= 9999 else 0
        except ValueError:
            pass

    # 3. Cím legvégén lévő csevegő-alkalmazás számláló:
    # Pl. 'Telegram (5)', 'Telegram Web (2)', 'Slack (4)'
    m = re.search(
        r'(?:Telegram|Slack|Discord|Messenger|WhatsApp|Chat)\s*(?:Web)?\s*[\(\[]([0-9]+)\+?[\)\]]$',
        clean,
        re.IGNORECASE,
    )
    if m:
        try:
            val = int(m.group(1))
            return val if 0 < val <= 999 else 0
        except ValueError:
            pass

    return 0


def extract_real_target_url(target_uri: str) -> str:
    """Kibontja a szolgáltatók által átirányított külső webcímeket (pl. Gmail /url?q=, Messenger l.php?u=)."""
    try:
        parsed = urllib.parse.urlsplit(target_uri)
        netloc = parsed.netloc.lower()
        # Gmail / Google átirányítás
        if "google." in netloc and parsed.path.startswith("/url"):
            qs = urllib.parse.parse_qs(parsed.query)
            if "q" in qs and qs["q"]:
                return qs["q"][0]
            if "url" in qs and qs["url"]:
                return qs["url"][0]
        # Facebook / Messenger átirányítás
        if ("messenger.com" in netloc or "facebook.com" in netloc) and ("l.php" in parsed.path or "l.messenger" in netloc):
            qs = urllib.parse.parse_qs(parsed.query)
            if "u" in qs and qs["u"]:
                return qs["u"][0]
    except Exception:
        pass
    return target_uri


# Kapcsolódó szolgáltatás-domain csoportok (amelyek azonos ökoszisztémát / belső infrastruktúrát képviselnek)
SERVICE_EQUIVALENT_GROUPS = [
    # Meta ökoszisztéma (Facebook, Messenger, WhatsApp, Instagram, Threads, CDN és belső sandbox proxy)
    {
        "facebook.com", "messenger.com", "fbsbx.com", "fbcdn.net",
        "m.me", "whatsapp.com", "whatsapp.net", "meta.com",
        "instagram.com", "threads.net"
    },
    # Google ökoszisztéma (Kereső, Gmail, Naptár, Drive, Docs, YouTube, fiókok és statikus tartalmak)
    {
        "google.com", "google.hu", "gstatic.com", "googleusercontent.com",
        "youtube.com", "youtu.be", "googlevideo.com", "googleapis.com",
        "ggpht.com"
    },
    # Microsoft ökoszisztéma (Outlook, Office, Teams, SharePoint, OneDrive, Live, Skype, Auth)
    {
        "microsoft.com", "live.com", "office.com", "office365.com",
        "sharepoint.com", "outlook.com", "teams.microsoft.com", "skype.com",
        "msftauth.net", "msauth.net", "microsoftonline.com"
    },
    # Slack ökoszisztéma
    {
        "slack.com", "slack-edge.com", "slack-msgs.com", "slack-redir.net"
    },
    # Telegram ökoszisztéma (fiókok, webes felület és témák)
    {
        "telegram.org", "t.me", "telegra.ph", "telesco.pe"
    },
]


def get_root_domain(host: str) -> str:
    """Kinyeri a regisztrálható fődomaint (pl. www.messenger.com -> messenger.com, sub.google.co.uk -> google.co.uk)."""
    if not host:
        return ""
    host = host.lower().split(":")[0].strip(".")
    parts = host.split(".")
    if len(parts) <= 1:
        return host

    two_part_tlds = ("co.uk", "org.uk", "gov.uk", "com.br", "co.jp", "com.au")
    if len(parts) >= 3 and ".".join(parts[-2:]) in two_part_tlds:
        return ".".join(parts[-3:])

    return ".".join(parts[-2:])


def are_domains_same_service(host_a: str, host_b: str) -> bool:
    """Eldönti, hogy a két domain cím ugyanazon webes szolgáltatás / ökoszisztéma része-e."""
    if not host_a or not host_b:
        return False

    root_a = get_root_domain(host_a)
    root_b = get_root_domain(host_b)

    if root_a and root_a == root_b:
        return True

    for group in SERVICE_EQUIVALENT_GROUPS:
        in_a = any(root_a == item or host_a == item or host_a.endswith("." + item) for item in group)
        in_b = any(root_b == item or host_b == item or host_b.endswith("." + item) for item in group)
        if in_a and in_b:
            return True

    return False


def is_auth_or_login_url(uri: str) -> bool:
    """Meghatározza, hogy az adott webcím bejelentkezési, azonosítási vagy belső szolgáltatás-proxyhoz tartozik-e."""
    try:
        parsed = urllib.parse.urlsplit(uri)
        netloc = parsed.netloc.lower().split(":")[0]
        path = parsed.path.lower()

        # Meta belső MAW (Multi-Account Web) proxy és háttér-kommunikációs végpontok
        if "fbsbx.com" in netloc or "maw_proxy_page" in path:
            return True

        # Ismert hitelesítési és azonosítási szerverek
        auth_hosts = (
            "accounts.google.", "login.microsoftonline.", "login.live.",
            "appleid.apple.", "auth.slack.", "auth0.", "okta.",
            "identity.", "cas.", "sso.", "msftauth.net", "msauth.net"
        )
        if any(h in netloc for h in auth_hosts):
            return True

        # Tipikus OAuth / SSO végpontok
        auth_paths = (
            "/oauth", "/oauth2", "/saml", "/sso", "/login", "/signin",
            "/auth", "/authenticate", "/session", "/checkpoint", "/maw_proxy_page"
        )
        if any(path.startswith(ap) or ap in path for ap in auth_paths):
            return True
    except Exception:
        pass
    return False


def is_external_link(tab_base_url: str, target_uri: str) -> bool:
    """Megvizsgálja, hogy a cél-hivatkozás külső böngészőben nyitandó-e meg a fül alapértelmezett szolgáltatásához képest."""
    try:
        real_target = extract_real_target_url(target_uri)
        parsed_target = urllib.parse.urlsplit(real_target)
        scheme = parsed_target.scheme.lower()

        if not scheme or scheme in ("javascript", "about", "data", "file"):
            return False

        if scheme not in ("http", "https"):
            if scheme in ("tg", "tel", "sms"):
                return False
            return True  # mailto:, magnet: stb.

        # Ha bejelentkezési / OAuth folyamat vagy belső proxy, a fülön belül kell maradnia a süti-izolációhoz
        if is_auth_or_login_url(real_target):
            return False

        parsed_base = urllib.parse.urlsplit(tab_base_url or "")
        base_host = parsed_base.netloc.lower().split(":")[0]
        target_host = parsed_target.netloc.lower().split(":")[0]
        target_path = parsed_target.path.lower()

        if not base_host:
            return False

        # Ha Messenger fülön vagyunk (messenger.com vagy m.me):
        if "messenger.com" in base_host or base_host == "m.me":
            # 1. Ha a célpont Facebook tartomány (facebook.com, fb.com, fb.me):
            if "facebook.com" in target_host or "fb.com" in target_host or "fb.me" in target_host:
                return True
            # 2. Ha az elért útvonal Facebook tartalomfunkció (esemény, csoport, videó, piactér stb.):
            # A Messengeren nincs belső /events/, /groups/, ezek mindig a Facebookra mutatnak.
            if any(target_path.startswith(p) for p in ("/events", "/groups", "/pages", "/watch", "/marketplace", "/photo", "/permalink", "/story")):
                return True

        if target_host == base_host:
            return False

        # Ha azonos ökoszisztémához / szolgáltatáshoz tartoznak
        if are_domains_same_service(base_host, target_host):
            # Kivétel: Google /url keresési átirányítás külső célponttal
            if "google." in base_host and "google." in target_host:
                if real_target != target_uri or parsed_target.path.startswith("/url"):
                    return True
            return False

        return True
    except Exception:
        return False


def load_config():
    try:
        os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    except Exception:
        pass

    cfg = json.loads(json.dumps(DEFAULT_CONFIG))

    # Ha a felhasználói config még nem létezik, de van sablon (pl. telepített /usr/share csomagban)
    target_path = CONFIG_PATH
    if not os.path.exists(target_path) and os.path.exists(TEMPLATE_CONFIG_PATH):
        target_path = TEMPLATE_CONFIG_PATH

    if os.path.exists(target_path):
        try:
            with open(target_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    cfg["version"] = APP_VERSION  # Mindig a futó alkalmazás verziója érvényesül
                    if isinstance(data.get("settings"), dict):
                        cfg["settings"].update(data["settings"])
                    if isinstance(data.get("profiles"), list) and len(data["profiles"]) > 0:
                        cfg["profiles"] = data["profiles"]
                    if isinstance(data.get("tabs"), list):
                        cfg["tabs"] = data["tabs"]

                    # Top-level visszamenőleges szinkronizáció
                    if "theme" in data:
                        cfg["theme"] = data["theme"]
                        cfg["settings"]["theme"] = data["theme"]
                    else:
                        cfg["theme"] = cfg["settings"].get("theme", "slate")

                    if "sidebarCollapsed" in data:
                        cfg["sidebarCollapsed"] = data["sidebarCollapsed"]
                        cfg["settings"]["sidebarCollapsed"] = data["sidebarCollapsed"]
                    else:
                        cfg["sidebarCollapsed"] = cfg["settings"].get("sidebarCollapsed", False)

                    cfg["activeTabId"] = data.get("activeTabId")
        except Exception as err:
            print(f"[WARN] Konfiguráció betöltési hiba ({err}), alapértelmezett használata.", file=sys.stderr)

    if cfg["theme"] not in VALID_THEMES:
        cfg["theme"] = "slate"
        cfg["settings"]["theme"] = "slate"

    # Fülek normalizálása
    normalized = []
    for idx, t in enumerate(cfg.get("tabs", [])):
        title = t.get("title") or t.get("name") or "Szolgáltatás"
        profile = t.get("profile") or t.get("profileId") or "default"
        url = t.get("url", "https://example.com")
        try:
            zoom_lvl = round(float(t.get("zoomLevel", 1.0)), 2)
            if zoom_lvl < 0.25 or zoom_lvl > 5.0:
                zoom_lvl = 1.0
        except (ValueError, TypeError):
            zoom_lvl = 1.0

        icon_resolved = resolve_service_icon(title, url, t.get("icon", ""))
        fav_clean = "" if icon_resolved != "globe" else (t.get("favicon") or "")
        fav_url_clean = _default_favicon_url(url) if icon_resolved != "globe" else (t.get("faviconUrl") or _default_favicon_url(url))
        unread_cnt = int(t.get("unreadCount", 0))
        if icon_resolved == "calendar":
            unread_cnt = 0

        normalized.append({
            "id": t.get("id") or f"tab-{uuid.uuid4().hex[:8]}",
            "title": title,
            "name": title,
            "url": url,
            "icon": icon_resolved,
            "profile": profile,
            "profileId": profile,
            "notificationsEnabled": bool(t.get("notificationsEnabled", True)),
            "unreadCount": unread_cnt,
            "order": int(t.get("order", idx)),
            "favicon": fav_clean,
            "faviconUrl": fav_url_clean,
            "zoomLevel": zoom_lvl
        })
    # Ha sablonból töltöttük be, és a felhasználói config még nem létezik, mentsük el a felhasználói XDG helyre
    if target_path != CONFIG_PATH and not os.path.exists(CONFIG_PATH):
        try:
            save_config(cfg)
        except Exception:
            pass

    cfg["tabs"] = normalized
    return cfg


def save_config(cfg):
    try:
        os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
        os.makedirs(DATA_DIR, exist_ok=True)
        if "settings" not in cfg or not isinstance(cfg["settings"], dict):
            cfg["settings"] = {
                "theme": cfg.get("theme", "slate"),
                "sidebarCollapsed": bool(cfg.get("sidebarCollapsed", False)),
                "minimizeToTrayOnClose": True,
                "startMinimized": False,
                "hardwareAcceleration": True
            }
        # Kétirányú szinkronban tartás a specifikáció és a meglévő kód között
        cfg["theme"] = cfg["settings"].get("theme", cfg.get("theme", "slate"))
        cfg["sidebarCollapsed"] = bool(cfg["settings"].get("sidebarCollapsed", cfg.get("sidebarCollapsed", False)))
        
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)
    except Exception as err:
        print(f"[Save Config Error] {err}", file=sys.stderr)


class TabbedClientWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="TabbedClient — Kezdőlap")
        self.set_wmclass("tabbedclient", "tabbedclient")
        self.set_default_size(1280, 840)
        self.set_position(Gtk.WindowPosition.CENTER)

        GLib.set_prgname("tabbedclient")
        GLib.set_application_name("TabbedClient")
        self.set_role("browser")
        
        # Hivatalos alkalmazás-ikonok beállítása (Bento dizájn multi-resolution lista)
        candidate_icon_dirs = [
            os.path.join(BASE_DIR, "icons"),
            os.path.join(BASE_DIR, "src-tauri", "icons"),
            "/usr/share/tabbedclient/icons",
            "/usr/share/icons/hicolor"
        ]
        icons_dir = next((d for d in candidate_icon_dirs if os.path.exists(d)), "")
        pixbufs = []
        for sz in (16, 24, 32, 48, 64, 128, 256, 512):
            fname = f"{sz}x{sz}.png" if sz != 512 else "icon.png"
            p = os.path.join(icons_dir, fname) if icons_dir else ""
            if not p or not os.path.exists(p):
                p = f"/usr/share/icons/hicolor/{sz}x{sz}/apps/tabbedclient.png"
            if not os.path.exists(p):
                p = f"/usr/share/tabbedclient/icons/{fname}"
            if os.path.exists(p):
                try:
                    pixbufs.append(GdkPixbuf.Pixbuf.new_from_file(p))
                except Exception:
                    pass

        if pixbufs:
            Gtk.Window.set_default_icon_list(pixbufs)
            self.set_icon_list(pixbufs)

        Gtk.Window.set_default_icon_name("tabbedclient")
        self.set_icon_name("tabbedclient")

        # Helyi ikontéma elérési út hozzáadása
        if icons_dir and os.path.exists(icons_dir):
            try:
                theme = Gtk.IconTheme.get_default()
                if theme:
                    theme.append_search_path(icons_dir)
            except Exception:
                pass

        # Automatikus asztali integráció (Zorin OS / GNOME tálca és indító regisztráció)
        try:
            has_system_desktop = os.path.exists("/usr/share/applications/tabbedclient.desktop")
            has_user_desktop = os.path.exists(os.path.expanduser("~/.local/share/applications/tabbedclient.desktop"))
            if not has_system_desktop and not has_user_desktop:
                from scripts.install_desktop import install_user_desktop_integration
                install_user_desktop_integration(silent=True)
        except Exception:
            pass

        self.set_skip_taskbar_hint(False)
        self.set_skip_pager_hint(False)

        if Notify:
            try:
                Notify.init("TabbedClient")
            except Exception as e:
                print(f"[Notify Init Warning] {e}", file=sys.stderr)

        self.config = load_config()
        self.data_managers = {}
        self.contexts = {}
        self.webviews = {}
        self.tab_webviews = {}
        self.previous_tab_id = None
        self.current_welcome_view = "dashboard"
        self._current_sidebar_width = None
        self._last_button_event = None
        self._context_menu = None
        self.tray = None
        self.tray_menu = None

        try:
            default_ctx = WebKit2.WebContext.get_default()
            if default_ctx:
                default_ctx.connect("download-started", self._on_download_started)
        except Exception as e:
            print(f"[Default WebContext Download Warning] {e}", file=sys.stderr)

        self.setup_ui()
        self.setup_tray()

        self.connect("delete-event", self.on_window_delete)
        self.connect("window-state-event", self.on_window_state_event)
        self.connect("key-press-event", self._on_window_key_press)

        # startMinimized kezelése
        if self.config.get("settings", {}).get("startMinimized", False) and self.tray:
            self.hide()
        else:
            self.show_all()

    def setup_tray(self):
        if not AppIndicator:
            return
        try:
            candidate_dirs = [
                os.path.join(BASE_DIR, "icons"),
                os.path.join(BASE_DIR, "src-tauri", "icons"),
                "/usr/share/tabbedclient/icons",
                "/usr/share/icons/hicolor/48x48/apps",
                "/usr/share/pixmaps"
            ]
            icon_theme_dir = next((d for d in candidate_dirs if os.path.exists(d)), None)
            icon_name = "tabbedclient"
            if hasattr(AppIndicator.Indicator, "new_with_path") and icon_theme_dir:
                self.tray = AppIndicator.Indicator.new_with_path(
                    "tabbedclient",
                    icon_name,
                    AppIndicator.IndicatorCategory.APPLICATION_STATUS,
                    icon_theme_dir
                )
            else:
                self.tray = AppIndicator.Indicator.new(
                    "tabbedclient",
                    icon_name,
                    AppIndicator.IndicatorCategory.APPLICATION_STATUS
                )
            self.tray.set_status(AppIndicator.IndicatorStatus.ACTIVE)
            self.tray.set_title("TabbedClient")
            self.update_tray_menu()
        except Exception as e:
            print(f"[Tray Init Warning] {e}", file=sys.stderr)
            self.tray = None

    def update_tray_menu(self):
        if not self.tray:
            return
        try:
            menu = Gtk.Menu()

            # 1. Ablak megjelenítése / elrejtése
            is_vis = self.is_visible()
            toggle_label = "Ablak elrejtése" if is_vis else "Ablak megjelenítése"
            item_toggle = Gtk.MenuItem(label=toggle_label)
            item_toggle.connect("activate", lambda *_: self.toggle_window_visibility())
            menu.append(item_toggle)

            menu.append(Gtk.SeparatorMenuItem())

            # 2. Kezdőlap
            item_home = Gtk.MenuItem(label="🏠 Kezdőlap")
            item_home.connect("activate", lambda *_: (self.show_window_and_present(), self.switch_to_tab("home")))
            menu.append(item_home)

            # 3. Fülek gyorsválasztása
            tabs = self.config.get("tabs", [])
            if tabs:
                menu.append(Gtk.SeparatorMenuItem())
                active_id = self.config.get("activeTabId")
                for t in tabs:
                    t_id = t.get("id")
                    t_title = t.get("title") or t.get("name") or "Szolgáltatás"
                    unread = t.get("unreadCount", 0)
                    badge = f" ({unread})" if unread > 0 else ""
                    mark = "● " if t_id == active_id else "  "
                    item_tab = Gtk.MenuItem(label=f"{mark}{t_title}{badge}")
                    item_tab.connect("activate", lambda *_, tid=t_id: (self.show_window_and_present(), self.switch_to_tab(tid)))
                    menu.append(item_tab)

            menu.append(Gtk.SeparatorMenuItem())

            # 4. Végleges kilépés
            item_quit = Gtk.MenuItem(label="Végleges kilépés")
            item_quit.connect("activate", lambda *_: self.quit_application())
            menu.append(item_quit)

            menu.show_all()
            self.tray_menu = menu
            self.tray.set_menu(menu)
        except Exception as err:
            print(f"[Tray Menu Error] {err}", file=sys.stderr)

    def toggle_window_visibility(self):
        if self.is_visible():
            self.hide()
        else:
            self.show_window_and_present()
        self.update_tray_menu()

    def restore_and_present(self):
        """
        Visszaállítja az ablakot, ha minimalizálva (iconified) vagy rejtve van,
        és az aktuális időbélyeggel előtérbe hozza, valamint aktívvá teszi.
        """
        self.deiconify()
        self.show_all()
        current_time = Gdk.CURRENT_TIME
        self.present_with_time(current_time)
        gdk_win = self.get_window()
        if gdk_win:
            try:
                gdk_win.show()
                gdk_win.raise_()
                gdk_win.focus(current_time)
            except Exception:
                pass
        self._notify_active_webview_resize()
        self.update_tray_menu()

    def show_window_and_present(self):
        self.restore_and_present()

    def quit_application(self):
        self._flush_config_save()
        Gtk.main_quit()

    def _apply_sidebar_width(self, collapsed: bool):
        width = SIDEBAR_COLLAPSED_WIDTH if collapsed else SIDEBAR_EXPANDED_WIDTH
        self._current_sidebar_width = width
        self.sidebar_box.set_size_request(width, -1)
        self.sidebar_webview.set_size_request(width, -1)
        if self.main_paned.get_position() != width:
            self.main_paned.set_position(width)
        GLib.timeout_add(60, self._notify_active_webview_resize)

    def _on_paned_position_changed(self, paned, param):
        expected = SIDEBAR_COLLAPSED_WIDTH if self.config.get("sidebarCollapsed") else SIDEBAR_EXPANDED_WIDTH
        if paned.get_position() != expected:
            paned.set_position(expected)

    def _notify_active_webview_resize(self):
        expected = SIDEBAR_COLLAPSED_WIDTH if self.config.get("sidebarCollapsed") else SIDEBAR_EXPANDED_WIDTH
        if self.main_paned.get_position() != expected:
            self.main_paned.set_position(expected)
        self.welcome_webview.run_javascript("window.dispatchEvent(new Event('resize'));", None, None, None)
        active_id = self.config.get("activeTabId")
        if active_id and active_id in self.tab_webviews:
            wv = self.tab_webviews[active_id]
            wv.run_javascript("window.dispatchEvent(new Event('resize'));", None, None, None)
        return False

    def on_window_state_event(self, widget, event):
        GLib.timeout_add(80, self._notify_active_webview_resize)
        return False

    def _on_sidebar_button_press(self, widget, event):
        if getattr(event, "button", None) == 3:
            try:
                self._last_button_event = event.copy()
            except Exception:
                self._last_button_event = event
        return False

    def setup_ui(self):
        initial_width = SIDEBAR_COLLAPSED_WIDTH if self.config.get("sidebarCollapsed") else SIDEBAR_EXPANDED_WIDTH
        self._current_sidebar_width = initial_width

        self.main_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        self.main_paned.set_wide_handle(False)
        self.main_paned.set_hexpand(True)
        self.main_paned.set_vexpand(True)
        self.add(self.main_paned)

        # 1. BAL PANEL: Vertikális Fülsáv (sidebar.html)
        self.sidebar_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.sidebar_box.set_size_request(initial_width, -1)
        self.sidebar_box.set_hexpand(False)
        self.sidebar_box.set_vexpand(True)
        self.main_paned.pack1(self.sidebar_box, resize=False, shrink=True)

        self.sidebar_content_manager = WebKit2.UserContentManager()
        self.sidebar_content_manager.register_script_message_handler("tabbedclient")
        self.sidebar_content_manager.register_script_message_handler("tabbedClient")
        self.sidebar_content_manager.connect("script-message-received::tabbedclient", self.on_script_message)
        self.sidebar_content_manager.connect("script-message-received::tabbedClient", self.on_script_message)

        self.sidebar_webview = WebKit2.WebView.new_with_user_content_manager(self.sidebar_content_manager)
        self.sidebar_webview.set_size_request(initial_width, -1)
        self.sidebar_webview.set_hexpand(False)
        self.sidebar_webview.set_vexpand(True)
        self.sidebar_webview.set_background_color(Gdk.RGBA(0.086, 0.094, 0.114, 1.0))
        self.sidebar_webview.connect("button-press-event", self._on_sidebar_button_press)
        self.sidebar_webview.connect("context-menu", lambda *_: True)

        s_settings = self.sidebar_webview.get_settings()
        s_settings.set_enable_javascript(True)
        s_settings.set_allow_file_access_from_file_urls(True)
        s_settings.set_allow_universal_access_from_file_urls(True)
        s_settings.set_enable_write_console_messages_to_stdout(True)

        sidebar_url = GLib.filename_to_uri(os.path.join(SRC_DIR, "sidebar.html"), None)
        self.sidebar_webview.load_uri(sidebar_url)
        self.sidebar_webview.connect("load-changed", self.on_webview_load_changed)
        self.sidebar_box.pack_start(self.sidebar_webview, True, True, 0)

        # 2. JOBB PANEL: Kezdőlap és szolgáltatás WebView-k konténere
        self.content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.content_box.set_hexpand(True)
        self.content_box.set_vexpand(True)
        self.main_paned.pack2(self.content_box, resize=True, shrink=True)

        self.main_paned.set_position(initial_width)
        self.main_paned.connect("notify::position", self._on_paned_position_changed)

        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.NONE)
        self.stack.set_hexpand(True)
        self.stack.set_vexpand(True)
        self.content_box.pack_start(self.stack, True, True, 0)

        self.welcome_cm = WebKit2.UserContentManager()
        self.welcome_cm.register_script_message_handler("tabbedclient")
        self.welcome_cm.register_script_message_handler("tabbedClient")
        self.welcome_cm.connect("script-message-received::tabbedclient", self.on_script_message)
        self.welcome_cm.connect("script-message-received::tabbedClient", self.on_script_message)

        self.welcome_webview = WebKit2.WebView.new_with_user_content_manager(self.welcome_cm)
        self.welcome_webview.set_hexpand(True)
        self.welcome_webview.set_vexpand(True)
        self.welcome_webview.set_background_color(Gdk.RGBA(0.059, 0.067, 0.082, 1.0))
        self.welcome_webview.connect("context-menu", lambda *_: True)

        w_settings = self.welcome_webview.get_settings()
        w_settings.set_enable_javascript(True)
        w_settings.set_allow_file_access_from_file_urls(True)
        w_settings.set_allow_universal_access_from_file_urls(True)
        w_settings.set_enable_write_console_messages_to_stdout(True)

        welcome_url = GLib.filename_to_uri(os.path.join(SRC_DIR, "welcome.html"), None)
        self.welcome_webview.load_uri(welcome_url)
        self.welcome_webview.connect("load-changed", self.on_webview_load_changed)
        self.welcome_webview.add_events(Gdk.EventMask.SCROLL_MASK | Gdk.EventMask.SMOOTH_SCROLL_MASK)
        self.welcome_webview.connect("scroll-event", self._on_webview_scroll)
        self.welcome_webview.connect("decide-policy", self._on_welcome_decide_policy)
        try:
            self.welcome_webview.connect("close", lambda w: (w.stop_emission_by_name("close"), True)[1])
        except Exception:
            pass

        self.stack.add_named(self.welcome_webview, "welcome")

        # 1. Fülek rendezése szigorúan a felvételi sorrendjük (order) szerint
        ordered_tabs = sorted(self.config.get("tabs", []), key=lambda t: int(t.get("order", 0)))

        # 2. Kezdő aktív fül meghatározása és ablakcím beállítása
        saved_active = self.config.get("activeTabId")
        if saved_active and any(t.get("id") == saved_active for t in ordered_tabs):
            self.previous_tab_id = saved_active
            active_tab = next(t for t in ordered_tabs if t.get("id") == saved_active)
            title = active_tab.get("title") or active_tab.get("name") or "Szolgáltatás"
            self.set_title(f"{title} — TabbedClient")
        else:
            self.config["activeTabId"] = None
            self.stack.set_visible_child_name("welcome")

        # 3. Automatikus szekvenciális előtöltés az összes fülre a felvételi sorrendben
        self._preload_tabs_in_order(ordered_tabs, saved_active)

    def _preload_tabs_in_order(self, ordered_tabs: list, active_tab_id: str):
        """
        Induláskor automatikusan betölti az összes felvett fül tartalmát
        szigorúan a felvételi sorrendjükben (az order mező szerint).
        Az aktív fül azonnal betöltődik, a további fülek pedig szekvenciálisan,
        egymás után ütemezve inicializálódnak a hálózat és a CPU túlterhelése nélkül.
        """
        if not ordered_tabs:
            return

        # Ha van kijelölt aktív fül, azt azonnal inicializáljuk és megjelenítjük
        if active_tab_id and any(t.get("id") == active_tab_id for t in ordered_tabs):
            active_tab = next(t for t in ordered_tabs if t.get("id") == active_tab_id)
            self._ensure_tab_webview(active_tab)
            self.stack.set_visible_child_name(active_tab_id)

        # Az összes többi fület pontosan a felvételi sorrendben töltjük be
        queue = [t for t in ordered_tabs if t.get("id") != active_tab_id]

        def _step_load(idx=0):
            if idx < len(queue):
                tab = queue[idx]
                self._ensure_tab_webview(tab)
                # 200 ms szünet a következő fül előtt a folyamatos és stabil hálózati betöltésért
                GLib.timeout_add(200, lambda: _step_load(idx + 1))
            return False

        if queue:
            initial_delay = 200 if active_tab_id else 50
            GLib.timeout_add(initial_delay, lambda: _step_load(0))

    def on_webview_load_changed(self, webview, load_event):
        if load_event == WebKit2.LoadEvent.FINISHED:
            self.sync_all_views()

    def on_window_delete(self, widget, event):
        self._flush_config_save()
        settings = self.config.get("settings", {})
        minimize_tray = settings.get("minimizeToTrayOnClose", True)
        if minimize_tray and self.tray is not None:
            self.hide()
            self.update_tray_menu()
            return True
        self.quit_application()
        return False

    def get_profile_context(self, profile_id: str) -> WebKit2.WebContext:
        if not profile_id:
            profile_id = "default"
        if profile_id in self.contexts:
            return self.contexts[profile_id]

        profile_path = os.path.join(PROFILES_DIR, profile_id)
        base_cache = os.path.join(profile_path, "cache")
        base_data = os.path.join(profile_path, "data")
        favicon_dir = os.path.join(profile_path, "favicons")
        os.makedirs(base_cache, exist_ok=True)
        os.makedirs(base_data, exist_ok=True)
        os.makedirs(favicon_dir, exist_ok=True)

        data_manager = WebKit2.WebsiteDataManager(
            base_cache_directory=base_cache,
            base_data_directory=base_data
        )
        context = WebKit2.WebContext.new_with_website_data_manager(data_manager)
        if hasattr(WebKit2, "CacheModel"):
            context.set_cache_model(WebKit2.CacheModel.WEB_BROWSER)
        if hasattr(context, "set_favicon_database_directory"):
            context.set_favicon_database_directory(favicon_dir)

        cookie_manager = context.get_cookie_manager()
        cookie_file = os.path.join(profile_path, "cookies.sqlite")
        cookie_manager.set_persistent_storage(
            cookie_file,
            WebKit2.CookiePersistentStorage.SQLITE
        )
        cookie_manager.set_accept_policy(WebKit2.CookieAcceptPolicy.NO_THIRD_PARTY)

        try:
            context.connect("download-started", self._on_download_started)
        except Exception as e:
            print(f"[Profile Context Download Warning] {e}", file=sys.stderr)

        self.contexts[profile_id] = context
        return context

    @staticmethod
    def get_download_dir() -> str:
        """Visszaadja a felhasználó letöltési könyvtárát (XDG vagy ~/Letöltések / ~/Downloads)."""
        dl_dir = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD)
        if dl_dir and os.path.isdir(dl_dir):
            return dl_dir
        home = os.path.expanduser("~")
        for candidate in ["Letöltések", "Downloads"]:
            p = os.path.join(home, candidate)
            if os.path.isdir(p):
                return p
        default_dir = os.path.join(home, "Letöltések")
        try:
            os.makedirs(default_dir, exist_ok=True)
            return default_dir
        except Exception:
            return home

    @staticmethod
    def _sanitize_filename(filename: str) -> str:
        if not filename:
            return "download"
        filename = urllib.parse.unquote(filename)
        filename = os.path.basename(filename.replace("\\", "/")).strip()
        filename = re.sub(r'[/*?:"<>|]', '_', filename)
        if not filename or filename in ('.', '..'):
            filename = "download"
        return filename

    @staticmethod
    def _get_unique_filepath(directory: str, filename: str) -> str:
        base, ext = os.path.splitext(filename)
        dest_path = os.path.join(directory, filename)
        counter = 1
        while os.path.exists(dest_path):
            dest_path = os.path.join(directory, f"{base} ({counter}){ext}")
            counter += 1
        return dest_path

    def _show_download_notification(self, title: str, body: str, filepath: str = ""):
        if Notify and Notify.is_initted():
            try:
                notif = Notify.Notification.new(title, body, "document-save")
                notif.show()
            except Exception as err:
                print(f"[Download Notify Error] {err}", file=sys.stderr)

    def _on_download_started(self, context_or_view, download: WebKit2.Download):
        """Kezeli a WebKit által indított letöltéseket (csatolmányok, képek, fájlok)."""
        print("[TabbedClient] Letöltés kezdeményezve...")
        try:
            download.connect("decide-destination", self._on_download_decide_destination)
            download.connect("finished", self._on_download_finished)
            download.connect("failed", self._on_download_failed)
        except Exception as err:
            print(f"[Download Connect Warning] {err}", file=sys.stderr)

    def _on_download_decide_destination(self, download: WebKit2.Download, suggested_filename: str) -> bool:
        dl_dir = self.get_download_dir()
        if not suggested_filename:
            resp = download.get_response() if hasattr(download, "get_response") else None
            if resp and hasattr(resp, "get_suggested_filename"):
                suggested_filename = resp.get_suggested_filename()
        if not suggested_filename:
            req = download.get_request() if hasattr(download, "get_request") else None
            uri = req.get_uri() if req else ""
            suggested_filename = os.path.basename(urllib.parse.urlparse(uri).path) or "download"

        clean_name = self._sanitize_filename(suggested_filename)
        dest_path = self._get_unique_filepath(dl_dir, clean_name)
        dest_uri = GLib.filename_to_uri(dest_path)

        download.set_destination(dest_uri)
        download.set_allow_overwrite(False)
        print(f"[TabbedClient] Letöltési cél meghatározva: {dest_path}")
        return True

    def _on_download_finished(self, download: WebKit2.Download):
        dest = download.get_destination() if hasattr(download, "get_destination") else None
        filepath = ""
        if dest:
            try:
                filepath, _ = GLib.filename_from_uri(dest)
            except Exception:
                filepath = dest.replace("file://", "")
        filename = os.path.basename(filepath) if filepath else "Fájl"
        print(f"[TabbedClient] Letöltés sikeresen befejeződött: {filepath}")
        self._show_download_notification(
            title="Letöltés kész",
            body=f"{filename} mentve a Letöltések mappába.",
            filepath=filepath
        )

    def _on_download_failed(self, download: WebKit2.Download, error):
        print(f"[TabbedClient Letöltési Hiba] {error}", file=sys.stderr)
        self._show_download_notification(
            title="Letöltési hiba",
            body=f"A letöltés meghiúsult: {error}",
            filepath=""
        )

    def _on_blob_download_message(self, ucm, js_result):
        """Kezeli a JavaScript DOM-ból érkező blob/data URL letöltéseket (Messenger, Telegram, Gmail)."""
        try:
            val = js_result.get_js_value()
            if not val or not val.is_string():
                return
            raw = val.to_string()
            payload = json.loads(raw)
            filename = payload.get("filename") or "download"
            data_url = payload.get("dataUrl") or ""
            mime_type = payload.get("mimeType") or ""

            if not data_url or not data_url.startswith("data:"):
                return

            header, b64data = data_url.split(",", 1)
            if not mime_type and ";" in header:
                mime_type = header.split(";")[0].replace("data:", "")

            base, ext = os.path.splitext(filename)
            if not ext and mime_type:
                guessed_ext = mimetypes.guess_extension(mime_type)
                if guessed_ext:
                    filename = f"{filename}{guessed_ext}"

            clean_filename = self._sanitize_filename(filename)
            dl_dir = self.get_download_dir()
            dest_path = self._get_unique_filepath(dl_dir, clean_filename)

            file_bytes = base64.b64decode(b64data)
            with open(dest_path, "wb") as f:
                f.write(file_bytes)

            print(f"[TabbedClient] Csatolmány sikeresen lementve: {dest_path}")
            self._show_download_notification(
                title="Letöltés kész",
                body=f"{clean_filename} mentve a Letöltések mappába.",
                filepath=dest_path
            )
        except Exception as e:
            print(f"[Blob Download Handler Error] {e}", file=sys.stderr)

    def _update_tab_favicon(self, tab_id: str, favicon_data: str = None, favicon_url: str = None):
        changed = False
        for t in self.config.get("tabs", []):
            if t.get("id") == tab_id:
                # Ismert szolgáltatásnál (Gmail, Naptár, Messenger stb.) soha ne tároljunk el
                # dinamikus, dátumos vagy rárajzolt unreadCountos weboldal-favicont
                svc_icon = resolve_service_icon(t.get("title", ""), t.get("url", ""), t.get("icon", ""))
                if svc_icon != "globe":
                    if t.get("icon") != svc_icon:
                        t["icon"] = svc_icon
                        changed = True
                    if t.get("favicon") or (t.get("faviconUrl") and "unreadcountfavicon" in t.get("faviconUrl")):
                        t["favicon"] = ""
                        t["faviconUrl"] = _default_favicon_url(t.get("url", ""))
                        changed = True
                    break

                if favicon_data and t.get("favicon") != favicon_data:
                    t["favicon"] = favicon_data
                    changed = True
                if favicon_url and t.get("faviconUrl") != favicon_url:
                    t["faviconUrl"] = favicon_url
                    changed = True
                break
        if changed:
            save_config(self.config)
            self.sync_all_views()

    def _on_permission_request(self, webview, request, tab_id: str):
        # 1. Értesítési engedélykérés
        if hasattr(WebKit2, 'NotificationPermissionRequest') and isinstance(request, WebKit2.NotificationPermissionRequest):
            tab = next((t for t in self.config.get("tabs", []) if t.get("id") == tab_id), None)
            if tab and tab.get("notificationsEnabled", True) is False:
                request.deny()
            else:
                request.allow()
            return True

        # 2. Eszközinformációk lekérdezése (hangszóró/mikrofon/kamera lista - elengedhetetlen a Gmail Meet / Chat hívásokhoz)
        if hasattr(WebKit2, 'DeviceInfoPermissionRequest') and isinstance(request, WebKit2.DeviceInfoPermissionRequest):
            request.allow()
            return True

        # 3. Médiaeszközök (mikrofon / kamera aktív használata a kommunikációs szolgáltatásokban)
        if hasattr(WebKit2, 'UserMediaPermissionRequest') and isinstance(request, WebKit2.UserMediaPermissionRequest):
            request.allow()
            return True

        # 4. DRM és Média kulcsrendszer engedélyezése (védett hang/videó lejátszás)
        if hasattr(WebKit2, 'MediaKeySystemPermissionRequest') and isinstance(request, WebKit2.MediaKeySystemPermissionRequest):
            request.allow()
            return True

        # 5. Vágólap hozzáférés engedélyezése
        if hasattr(WebKit2, 'ClipboardPermissionRequest') and isinstance(request, WebKit2.ClipboardPermissionRequest):
            request.allow()
            return True

        # 6. Egyéb jogosultságok (pl. Geolocation): alapértelmezett védelem
        request.deny()
        return True

    def _on_show_notification(self, webview, notification, tab_id: str):
        tab = next((t for t in self.config.get("tabs", []) if t.get("id") == tab_id), None)
        if tab and tab.get("notificationsEnabled", True) is False:
            return True

        title = notification.get_title() or "Új értesítés"
        body = notification.get_body() or ""
        tab_name = tab.get("title") or tab.get("name") or "Szolgáltatás" if tab else "Szolgáltatás"

        is_active = (self.config.get("activeTabId") == tab_id and self.is_visible())
        if not is_active:
            if Notify and Notify.is_initted():
                try:
                    notif = Notify.Notification.new(f"[{tab_name}] {title}", body, "dialog-information")
                    notif.show()
                except Exception as err:
                    print(f"[Notify Error] {err}", file=sys.stderr)
        return True

    def _on_tab_title_changed(self, webview, param, tab_id: str):
        new_title = webview.get_title() or ""
        tab = next((t for t in self.config.get("tabs", []) if t.get("id") == tab_id), None)
        if not tab:
            return

        # Olvasatlan számláló kinyerése a címből megbízható szabályokkal
        count = extract_unread_count(new_title, tab.get("url", ""))
        if tab.get("unreadCount", 0) != count:
            tab["unreadCount"] = count
            save_config(self.config)
            self.sync_all_views()

    def _on_unread_message(self, user_content_manager, js_result, tab_id: str):
        try:
            val = js_result.get_js_value()
            if val.is_number():
                count = int(val.to_double())
            elif val.is_string():
                count = int(val.to_string())
            else:
                return
        except Exception:
            return

        count = max(0, min(count, 9999))
        tab = next((t for t in self.config.get("tabs", []) if t.get("id") == tab_id), None)
        if tab and tab.get("unreadCount", 0) != count:
            tab["unreadCount"] = count
            save_config(self.config)
            self.sync_all_views()

    def open_external_uri(self, uri: str, in_background: bool = False):
        if not uri:
            return
        real_uri = extract_real_target_url(uri)
        if not real_uri or real_uri.startswith("about:") or real_uri.startswith("javascript:"):
            return

        # Ha Messenger Facebook esemény vagy csoport link: alakítsuk közvetlen facebook.com URL-re
        if "messenger.com" in real_uri and any(p in real_uri for p in ("/events", "/groups", "/pages", "/watch", "/marketplace", "/photo")):
            real_uri = real_uri.replace("https://www.messenger.com", "https://www.facebook.com").replace("https://messenger.com", "https://www.facebook.com")
        elif real_uri.startswith(("/events", "/groups", "/pages", "/watch", "/marketplace", "/photo")):
            real_uri = f"https://www.facebook.com{real_uri}"

        print(f"[TabbedClient] Külső link megnyitása alapértelmezett böngészőben: {real_uri} (háttérben: {in_background})")

        launched = False

        # 1. GIO AppInfo (modern Freedesktop / GNOME / Zorin OS szabvány)
        try:
            if hasattr(Gio.AppInfo, "launch_default_for_uri"):
                launched = bool(Gio.AppInfo.launch_default_for_uri(real_uri, None))
        except Exception as e:
            print(f"[Open External URI Gio Warning] {e}", file=sys.stderr)

        # 2. Közvetlen xdg-open parancs (Linux asztali környezetek)
        if not launched:
            try:
                subprocess.Popen(["xdg-open", real_uri], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                launched = True
            except Exception:
                pass

        # 3. Python webbrowser modul (minden platform)
        if not launched:
            try:
                import webbrowser
                launched = bool(webbrowser.open(real_uri))
            except Exception as e:
                print(f"[Open External URI Webbrowser Warning] {e}", file=sys.stderr)

        # 4. Gtk.show_uri fallback
        if not launched:
            try:
                time = Gtk.get_current_event_time() or Gdk.CURRENT_TIME
                if hasattr(Gtk, "show_uri_on_window") and self.get_window():
                    Gtk.show_uri_on_window(self, real_uri, time)
                    launched = True
                elif hasattr(Gtk, "show_uri") and hasattr(self, "get_screen") and self.get_screen():
                    Gtk.show_uri(self.get_screen(), real_uri, time)
                    launched = True
            except Exception:
                pass

        # Ha háttérben kérték: megerősítjük és visszaállítjuk a TabbedClient fókuszát
        if in_background:
            self._keep_window_focused()

    def _keep_window_focused(self):
        """Garantálja, hogy a külső böngésző a háttérben nyíljon meg, a fókusz a TabbedClient ablakon marad."""
        def _refocus():
            try:
                cur_time = Gtk.get_current_event_time() or Gdk.CURRENT_TIME
                self.present_with_time(cur_time)
                win = self.get_window()
                if win:
                    win.focus(cur_time)
                active_id, wv = self._get_active_tab_id_and_webview()
                if wv and hasattr(wv, "grab_focus"):
                    wv.grab_focus()
            except Exception:
                pass
            return False

        _refocus()
        GLib.idle_add(_refocus)
        GLib.timeout_add(100, _refocus)
        GLib.timeout_add(250, _refocus)
        GLib.timeout_add(500, _refocus)

    def _on_bg_link_message(self, ucm, js_result):
        """Kezeli a weboldal DOM-jából Ctrl+bal klikk vagy középső egérgombbal küldött háttérlink-üzeneteket."""
        try:
            val = js_result.get_js_value()
            if val and val.is_string():
                url = val.to_string().strip()
                if url:
                    self.open_external_uri(url, in_background=True)
        except Exception as e:
            print(f"[Bg Link Error] {e}", file=sys.stderr)

    def _on_welcome_decide_policy(self, webview, decision, decision_type):
        if decision_type in (WebKit2.PolicyDecisionType.NAVIGATION_ACTION, WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION):
            nav_action = decision.get_navigation_action()
            req = nav_action.get_request() if nav_action else None
            uri = req.get_uri() if req else None
            if uri and (uri.startswith("http://") or uri.startswith("https://")):
                self.open_external_uri(uri)
                decision.ignore()
                return True
        return False

    def _on_create_webview(self, webview, navigation_action, tab_id: str):
        """Kezeli a target='_blank' vagy window.open() hívásokat."""
        req = navigation_action.get_request() if navigation_action else None
        uri = req.get_uri() if req else None

        modifiers = navigation_action.get_modifiers() if navigation_action else 0
        ctrl_pressed = bool(modifiers & Gdk.ModifierType.CONTROL_MASK)
        mouse_btn = navigation_action.get_mouse_button() if navigation_action else 0
        is_gesture = navigation_action.is_user_gesture() if navigation_action else False

        tab = next((t for t in self.config.get("tabs", []) if t.get("id") == tab_id), None)
        tab_url = tab.get("url", "") if tab else (webview.get_uri() or "")

        if uri and not uri.startswith("about:") and not uri.startswith("javascript:"):
            real_url = extract_real_target_url(uri)
            if real_url.startswith("blob:"):
                return None
            if ctrl_pressed or mouse_btn == 2:
                self.open_external_uri(real_url, in_background=True)
                return None
            if is_auth_or_login_url(real_url):
                webview.load_uri(real_url)
                return None
            if is_external_link(tab_url, real_url):
                self.open_external_uri(real_url)
                return None
            else:
                webview.load_uri(real_url)
                return None

        # Ha nem felhasználói gesztus indította és nincs konkrét URI
        if not is_gesture:
            return None

        # Ha az URI a létrehozás pillanatában még nem ismert, de van felhasználói gesztus
        try:
            temp_wv = WebKit2.WebView.new_with_context(webview.get_context())

            def _on_temp_decide_policy(temp_view, decision, decision_type):
                if decision_type == WebKit2.PolicyDecisionType.RESPONSE:
                    if hasattr(decision, "is_mime_type_supported") and not decision.is_mime_type_supported():
                        if hasattr(decision, "download"):
                            decision.download()
                        GLib.idle_add(temp_view.destroy)
                        return True
                    resp = decision.get_response() if hasattr(decision, "get_response") else None
                    if resp and hasattr(resp, "get_suggested_filename") and resp.get_suggested_filename():
                        if hasattr(decision, "download"):
                            decision.download()
                        GLib.idle_add(temp_view.destroy)
                        return True

                if decision_type == WebKit2.PolicyDecisionType.NAVIGATION_ACTION:
                    na = decision.get_navigation_action()
                    r = na.get_request() if na else None
                    u = r.get_uri() if r else None
                    temp_mods = na.get_modifiers() if na else 0
                    temp_ctrl = bool(temp_mods & Gdk.ModifierType.CONTROL_MASK) or ctrl_pressed
                    temp_mouse = na.get_mouse_button() if na else mouse_btn
                    if u and not u.startswith("about:") and not u.startswith("javascript:"):
                        real_u = extract_real_target_url(u)
                        if real_u.startswith("blob:"):
                            if hasattr(decision, "download"):
                                decision.download()
                            GLib.idle_add(temp_view.destroy)
                            return True
                        elif temp_ctrl or temp_mouse == 2:
                            self.open_external_uri(real_u, in_background=True)
                        elif is_auth_or_login_url(real_u):
                            webview.load_uri(real_u)
                        else:
                            curr_tab = next((t for t in self.config.get("tabs", []) if t.get("id") == tab_id), None)
                            curr_tab_url = curr_tab.get("url", "") if curr_tab else (webview.get_uri() or "")
                            if is_external_link(curr_tab_url, real_u):
                                self.open_external_uri(real_u)
                            else:
                                webview.load_uri(real_u)
                decision.ignore()
                GLib.idle_add(temp_view.destroy)
                return True

            temp_wv.connect("decide-policy", _on_temp_decide_policy)
            GLib.timeout_add(10000, temp_wv.destroy)
            return temp_wv
        except Exception as err:
            print(f"[Create WebView Warning] {err}", file=sys.stderr)
            return None

    def _on_decide_policy(self, webview, decision, decision_type, tab_id: str):
        """Kezeli a navigációs döntéseket (új ablak, link kattintás, külső domain, csatolmány-letöltések)."""
        tab = next((t for t in self.config.get("tabs", []) if t.get("id") == tab_id), None)
        tab_url = tab.get("url", "") if tab else (webview.get_uri() or "")

        # 0. Válasz (RESPONSE) szintű döntés: csatolmányok, képek és letölthető fájlok kezelése
        if decision_type == WebKit2.PolicyDecisionType.RESPONSE:
            if hasattr(decision, "is_mime_type_supported") and not decision.is_mime_type_supported():
                if hasattr(decision, "download"):
                    decision.download()
                    return True
            resp = decision.get_response() if hasattr(decision, "get_response") else None
            if resp and hasattr(resp, "get_suggested_filename") and resp.get_suggested_filename():
                if hasattr(decision, "download"):
                    decision.download()
                    return True
            return False

        # 1. Új ablak művelet (pl. link target='_blank' vagy window.open)
        if decision_type == WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION:
            nav_action = decision.get_navigation_action()
            is_gesture = nav_action.is_user_gesture() if nav_action else False
            req = nav_action.get_request() if nav_action else None
            uri = req.get_uri() if req else None
            modifiers = nav_action.get_modifiers() if nav_action else 0
            ctrl_pressed = bool(modifiers & Gdk.ModifierType.CONTROL_MASK)
            mouse_btn = nav_action.get_mouse_button() if nav_action else 0

            if uri and not uri.startswith("about:") and not uri.startswith("javascript:"):
                real_url = extract_real_target_url(uri)
                if real_url.startswith("blob:"):
                    if hasattr(decision, "download"):
                        decision.download()
                        return True
                elif ctrl_pressed or mouse_btn == 2:
                    self.open_external_uri(real_url, in_background=True)
                elif is_auth_or_login_url(real_url):
                    webview.load_uri(real_url)
                elif is_gesture:
                    if is_external_link(tab_url, real_url):
                        self.open_external_uri(real_url)
                    else:
                        webview.load_uri(real_url)
            decision.ignore()
            return True

        # 2. Bármilyen navigációs művelet (LINK_CLICKED, OTHER, REDIRECT, stb.)
        if decision_type == WebKit2.PolicyDecisionType.NAVIGATION_ACTION:
            nav_action = decision.get_navigation_action()
            if not nav_action:
                return False

            mouse_btn = nav_action.get_mouse_button()
            modifiers = nav_action.get_modifiers()
            ctrl_pressed = bool(modifiers & Gdk.ModifierType.CONTROL_MASK)
            nav_type = nav_action.get_navigation_type()
            is_gesture = nav_action.is_user_gesture()

            req = nav_action.get_request()
            uri = req.get_uri() if req else None
            if not uri or uri.startswith("about:") or uri.startswith("javascript:"):
                return False

            # Blob URL-ek közvetlen letöltése navigáció helyett
            if uri.startswith("blob:"):
                if hasattr(decision, "download"):
                    decision.download()
                    return True

            # Középső egérgomb vagy Ctrl + bal klikk mindig külső böngészőben, háttérben nyílik
            if mouse_btn == 2 or ctrl_pressed:
                self.open_external_uri(uri, in_background=True)
                decision.ignore()
                return True

            real_target = extract_real_target_url(uri)
            if is_auth_or_login_url(real_target):
                return False

            # Ha a hivatkozás külső böngészőben nyitandó meg (pl. Messengeren Facebook esemény vagy külső link):
            # Akkor is megnyitjuk külső böngészőben, ha a weboldal belső JavaScriptje (pl. React SPA router)
            # vezérelte a kattintást (nav_type == OTHER), megakadályozva a csevegő felület felülírását!
            if is_external_link(tab_url, real_target):
                self.open_external_uri(real_target)
                decision.ignore()
                return True

        return False

    def _flush_config_save(self):
        if hasattr(self, "_config_save_timer") and self._config_save_timer:
            try:
                GLib.source_remove(self._config_save_timer)
            except Exception:
                pass
            self._config_save_timer = None
        save_config(self.config)

    def _schedule_config_save(self):
        if hasattr(self, "_config_save_timer") and self._config_save_timer:
            try:
                GLib.source_remove(self._config_save_timer)
            except Exception:
                pass
        def _do_save():
            save_config(self.config)
            self._config_save_timer = None
            return False
        self._config_save_timer = GLib.timeout_add(300, _do_save)

    def _save_webview_zoom(self, webview, zoom_level: float):
        tab_id = None
        for tid, wv in self.tab_webviews.items():
            if wv == webview:
                tab_id = tid
                break
        if not tab_id:
            tab_id = self.config.get("activeTabId")
        if tab_id and tab_id != "home":
            self._save_tab_zoom(tab_id, zoom_level)

    def _save_tab_zoom(self, tab_id: str, zoom_level: float):
        target_tab = next((t for t in self.config.get("tabs", []) if t.get("id") == tab_id), None)
        if target_tab:
            rounded_zoom = round(float(zoom_level), 2)
            rounded_zoom = max(0.25, min(5.0, rounded_zoom))
            target_tab["zoomLevel"] = rounded_zoom
            self._schedule_config_save()

    def _on_webview_scroll(self, webview, event):
        """Kezeli a Ctrl + egérgörgő nagyítást és kicsinyítést (Zoom In / Zoom Out) és perzisztálja a beállítást."""
        if bool(event.state & Gdk.ModifierType.CONTROL_MASK):
            current_zoom = webview.get_zoom_level()
            new_zoom = current_zoom

            if event.direction == Gdk.ScrollDirection.UP:
                new_zoom = min(5.0, current_zoom + 0.1)
            elif event.direction == Gdk.ScrollDirection.DOWN:
                new_zoom = max(0.25, current_zoom - 0.1)
            elif event.direction == Gdk.ScrollDirection.SMOOTH:
                has_deltas, dx, dy = event.get_scroll_deltas()
                if has_deltas:
                    if dy < 0:
                        new_zoom = min(5.0, current_zoom + 0.1)
                    elif dy > 0:
                        new_zoom = max(0.25, current_zoom - 0.1)

            if abs(new_zoom - current_zoom) > 0.001:
                rounded_zoom = round(new_zoom, 2)
                webview.set_zoom_level(rounded_zoom)
                self._save_webview_zoom(webview, rounded_zoom)
            return True

        return False

    def _get_clipboard_image_or_file_data(self) -> dict | None:
        """Kiolvassa a vágólapról a képadatot (közvetlen kép vagy fájl-URI kép/dokumentum formátumban)."""
        try:
            clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
        except Exception:
            return None

        # 1. Közvetlen kép a vágólapon (böngészőből másolt kép, képernyőmentés Flameshot/GNOME eszközből)
        try:
            if clipboard.wait_is_image_available():
                pixbuf = clipboard.wait_for_image()
                if pixbuf:
                    ok, buffer = pixbuf.save_to_bufferv("png", [], [])
                    if ok and buffer:
                        return {
                            "type": "image/png",
                            "filename": "pasted_image.png",
                            "data": base64.b64encode(buffer).decode("ascii")
                        }
        except Exception as e:
            print(f"[Clipboard Image Warning] {e}", file=sys.stderr)

        # 2. Fájl-URI-k a vágólapon (pl. fájlkezelőből - Nautilus, Nemo, Thunar stb. - kimásolt fájl)
        try:
            uris = clipboard.wait_for_uris()
            if uris:
                for uri in uris:
                    filepath = None
                    try:
                        filepath, _ = GLib.filename_from_uri(uri)
                    except Exception:
                        if uri.startswith("file://"):
                            filepath = urllib.parse.unquote(uri[7:])

                    if filepath and os.path.isfile(filepath):
                        mime_type, _ = mimetypes.guess_type(filepath)
                        ext = os.path.splitext(filepath)[1].lower()
                        if not mime_type:
                            if ext in ('.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.svg'):
                                mime_type = f"image/{ext.replace('.', '')}"
                            elif ext in ('.pdf',):
                                mime_type = "application/pdf"
                            else:
                                mime_type = "application/octet-stream"

                        try:
                            with open(filepath, "rb") as f:
                                file_bytes = f.read()
                            if file_bytes:
                                return {
                                    "type": mime_type,
                                    "filename": os.path.basename(filepath),
                                    "data": base64.b64encode(file_bytes).decode("ascii")
                                }
                        except Exception:
                            pass
        except Exception as e:
            print(f"[Clipboard URI Warning] {e}", file=sys.stderr)

        return None

    def _inject_clipboard_file_to_webview(self, webview, file_info: dict):
        """Szintetikus ClipboardEvent('paste') és DragEvent('drop') eseményeket vált ki a weboldalon a fájl csatolásához."""
        data_b64 = file_info.get("data", "")
        mime_type = file_info.get("type", "image/png")
        filename = file_info.get("filename", "pasted_image.png")

        js_code = f"""
(function() {{
    try {{
        var b64Data = "{data_b64}";
        var mime = "{mime_type}";
        var fname = "{filename}";

        var binStr = atob(b64Data);
        var len = binStr.length;
        var bytes = new Uint8Array(len);
        for (var i = 0; i < len; i++) {{
            bytes[i] = binStr.charCodeAt(i);
        }}
        var blob = new Blob([bytes], {{ type: mime }});
        var file = new File([blob], fname, {{ type: mime, lastModified: Date.now() }});

        var dt = new DataTransfer();
        dt.items.add(file);

        var active = document.activeElement || document.body;
        if (active && active.tagName === 'IFRAME') {{
            try {{
                var doc = active.contentDocument || active.contentWindow.document;
                if (doc && doc.activeElement) active = doc.activeElement;
            }} catch(e) {{}}
        }}

        // 1. Szintetikus paste esemény (Messenger, Gmail, Slack, Telegram Web ezt preferálja)
        var pasteEvt = new ClipboardEvent('paste', {{
            bubbles: true,
            cancelable: true,
            composed: true,
            clipboardData: dt
        }});
        active.dispatchEvent(pasteEvt);

        // 2. Ha a webapp drop eseményre támaszkodik vagy nem preventDefault-ozta
        if (!pasteEvt.defaultPrevented) {{
            var dropEvt = new DragEvent('drop', {{
                bubbles: true,
                cancelable: true,
                composed: true,
                dataTransfer: dt
            }});
            active.dispatchEvent(dropEvt);
        }}
        return true;
    }} catch(err) {{
        console.error('[TabbedClient Paste Injection Error]', err);
        return false;
    }}
}})();
"""
        try:
            webview.run_javascript(js_code, None, None, None)
        except Exception as err:
            print(f"[WebView Paste Injection Warning] {err}", file=sys.stderr)

    def _on_webview_key_press(self, webview, event, tab_id: str):
        is_ctrl_v = bool(event.state & Gdk.ModifierType.CONTROL_MASK) and event.keyval in (Gdk.KEY_v, Gdk.KEY_V)
        is_shift_ins = bool(event.state & Gdk.ModifierType.SHIFT_MASK) and event.keyval in (Gdk.KEY_Insert, Gdk.KEY_KP_Insert)

        if is_ctrl_v or is_shift_ins:
            clip_data = self._get_clipboard_image_or_file_data()
            if clip_data:
                self._inject_clipboard_file_to_webview(webview, clip_data)
                return True
        return False

    def _on_window_key_press(self, widget, event):
        """Kezeli a billentyűzet-alapú nagyítást: Ctrl+, Ctrl-, Ctrl0 és a vágólap kép/fájl beillesztést."""
        if bool(event.state & Gdk.ModifierType.CONTROL_MASK):
            keyval = event.keyval
            if keyval in (Gdk.KEY_plus, Gdk.KEY_equal, Gdk.KEY_KP_Add):
                self._zoom_active_view(0.1)
                return True
            elif keyval in (Gdk.KEY_minus, Gdk.KEY_KP_Subtract):
                self._zoom_active_view(-0.1)
                return True
            elif keyval in (Gdk.KEY_0, Gdk.KEY_KP_0):
                self._reset_active_zoom()
                return True
            elif keyval in (Gdk.KEY_v, Gdk.KEY_V):
                active_id, wv = self._get_active_tab_id_and_webview()
                if wv and active_id != "welcome":
                    clip_data = self._get_clipboard_image_or_file_data()
                    if clip_data:
                        self._inject_clipboard_file_to_webview(wv, clip_data)
                        return True
        elif bool(event.state & Gdk.ModifierType.SHIFT_MASK):
            if event.keyval in (Gdk.KEY_Insert, Gdk.KEY_KP_Insert):
                active_id, wv = self._get_active_tab_id_and_webview()
                if wv and active_id != "welcome":
                    clip_data = self._get_clipboard_image_or_file_data()
                    if clip_data:
                        self._inject_clipboard_file_to_webview(wv, clip_data)
                        return True
        return False

    def _get_active_tab_id_and_webview(self):
        active_id = self.config.get("activeTabId")
        if active_id and active_id in self.tab_webviews:
            return active_id, self.tab_webviews[active_id]
        if hasattr(self, "welcome_webview") and self.stack.get_visible_child_name() == "welcome":
            return "welcome", self.welcome_webview
        return None, None

    def _zoom_active_view(self, delta: float):
        tab_id, wv = self._get_active_tab_id_and_webview()
        if wv:
            cur = wv.get_zoom_level()
            target = max(0.25, min(5.0, round(cur + delta, 2)))
            wv.set_zoom_level(target)
            if tab_id and tab_id != "welcome":
                self._save_tab_zoom(tab_id, target)

    def _reset_active_zoom(self):
        tab_id, wv = self._get_active_tab_id_and_webview()
        if wv:
            wv.set_zoom_level(1.0)
            if tab_id and tab_id != "welcome":
                self._save_tab_zoom(tab_id, 1.0)

    def _on_webview_close(self, webview, tab_id: str):
        """
        Kezeli a fülön belüli JavaScript window.close() hívásokat.
        Megakadályozza, hogy a weboldal (pl. Telegram Web téma vagy modál bezárásakor)
        a WebKit alapértelmezett viselkedése révén megsemmisítse a főablakot (gtk_widget_destroy).
        """
        try:
            webview.stop_emission_by_name("close")
        except Exception:
            pass
        return True

    def _on_web_process_terminated(self, webview, reason, tab_id: str):
        """Kezeli a WebKit renderelő folyamatának váratlan leállását, és automatikusan helyreállítja a fület."""
        print(f"[WebKit Warning] WebProcess terminálódott a(z) {tab_id} fülön (indok: {reason}). Automatikus helyreállítás...", file=sys.stderr)
        try:
            webview.stop_emission_by_name("web-process-terminated")
        except Exception:
            pass
        GLib.timeout_add(800, lambda: (webview.reload(), False)[1])
        return True

    def _on_web_process_crashed(self, webview, tab_id: str):
        """Kezeli a WebKit renderelő folyamatának összeomlását régebbi WebKit2 futtatókörnyezetben."""
        print(f"[WebKit Warning] WebProcess összeomlott a(z) {tab_id} fülön. Automatikus helyreállítás...", file=sys.stderr)
        try:
            webview.stop_emission_by_name("web-process-crashed")
        except Exception:
            pass
        GLib.timeout_add(800, lambda: (webview.reload(), False)[1])
        return True

    def _ensure_tab_webview(self, tab: dict):
        tab_id = tab.get("id")
        if not tab_id or tab_id in self.webviews:
            return
        profile = tab.get("profile") or tab.get("profileId") or "default"
        url = tab.get("url", "https://example.com")

        ctx = self.get_profile_context(profile)

        wv_settings = WebKit2.Settings()
        wv_settings.set_enable_javascript(True)
        wv_settings.set_enable_webaudio(True)
        wv_settings.set_enable_media_stream(True)
        if hasattr(wv_settings, "set_enable_webrtc"):
            wv_settings.set_enable_webrtc(True)
        if hasattr(wv_settings, "set_media_playback_requires_user_gesture"):
            wv_settings.set_media_playback_requires_user_gesture(False)
        wv_settings.set_enable_smooth_scrolling(True)
        wv_settings.set_javascript_can_access_clipboard(True)
        wv_settings.set_allow_file_access_from_file_urls(True)
        wv_settings.set_allow_universal_access_from_file_urls(True)
        if hasattr(wv_settings, "set_allow_top_navigation_to_data_urls"):
            wv_settings.set_allow_top_navigation_to_data_urls(True)
        if hasattr(wv_settings, "set_zoom_text_only"):
            wv_settings.set_zoom_text_only(False)
        if hasattr(wv_settings, "set_enable_page_cache"):
            wv_settings.set_enable_page_cache(True)
        if hasattr(wv_settings, "set_enable_dns_prefetching"):
            wv_settings.set_enable_dns_prefetching(True)

        # Hardveres gyorsítás és WebGL beállítások a webes témák és canvas stabilitásához
        hw_accel = self.config.get("settings", {}).get("hardwareAcceleration", True)
        if hasattr(wv_settings, "set_hardware_acceleration_policy"):
            policy = WebKit2.HardwareAccelerationPolicy.ON_DEMAND if hw_accel else WebKit2.HardwareAccelerationPolicy.NEVER
            wv_settings.set_hardware_acceleration_policy(policy)
        if hasattr(wv_settings, "set_enable_webgl"):
            wv_settings.set_enable_webgl(True)
        if hasattr(wv_settings, "set_enable_accelerated_2d_canvas"):
            wv_settings.set_enable_accelerated_2d_canvas(hw_accel)

        wv_settings.set_user_agent(
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
        )

        wv = WebKit2.WebView.new_with_context(ctx)
        wv.set_settings(wv_settings)
        wv.set_hexpand(True)
        wv.set_vexpand(True)
        wv.set_background_color(Gdk.RGBA(0.059, 0.067, 0.082, 1.0))

        # Nagyítás és billentyűzetkezelés (Ctrl + egérgörgő, Ctrl + V képbeillesztés)
        wv.add_events(
            Gdk.EventMask.SCROLL_MASK
            | Gdk.EventMask.SMOOTH_SCROLL_MASK
            | Gdk.EventMask.KEY_PRESS_MASK
            | Gdk.EventMask.KEY_RELEASE_MASK
        )
        wv.connect("scroll-event", self._on_webview_scroll)
        wv.connect("key-press-event", self._on_webview_key_press, tab_id)
        saved_zoom = float(tab.get("zoomLevel", 1.0))
        if saved_zoom < 0.25 or saved_zoom > 5.0:
            saved_zoom = 1.0
        wv.set_zoom_level(saved_zoom)

        # DOM szintű híd: háttérlink-megnyitás (Ctrl+klikk), Drag & Drop és csatolmány-letöltés
        try:
            ucm = wv.get_user_content_manager()
            ucm.register_script_message_handler("tabbedclient_bg_link")
            ucm.connect("script-message-received::tabbedclient_bg_link", self._on_bg_link_message)
            ucm.register_script_message_handler("tabbedclient_blob_download")
            ucm.connect("script-message-received::tabbedclient_blob_download", self._on_blob_download_message)
            ucm.register_script_message_handler("tabbedclient_unread")
            ucm.connect("script-message-received::tabbedclient_unread", lambda mgr, res: self._on_unread_message(mgr, res, tab_id))

            bg_and_dnd_script = (
                "(function() {"
                "  if (window.__tabbedclient_helpers_installed) return;"
                "  window.__tabbedclient_helpers_installed = true;"
                "  function __syncUnreadCount() {"
                "    try {"
                "      var count = 0;"
                "      var loc = (window.location.href || '').toLowerCase();"
                "      if (loc.indexOf('calendar.google') !== -1) {"
                "        if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.tabbedclient_unread) {"
                "          window.webkit.messageHandlers.tabbedclient_unread.postMessage(0);"
                "        }"
                "        return;"
                "      }"
                "      var title = document.title || '';"
                "      var m = title.match(/^(?:\\*\\s*)?[\\(\\[]([0-9]+)\\+?[\\)\\]]/) ||"
                "              title.match(/(?:Inbox|Beérkező levelek|Beérkezett üzenetek|Messages|Üzenetek|Chats|Csevegések)\\s*[\\(\\[]([0-9]+)\\+?[\\)\\]]/i) ||"
                "              title.match(/(?:Telegram|Slack|Discord|Messenger|WhatsApp|Chat)\\s*(?:Web)?\\s*[\\(\\[]([0-9]+)\\+?[\\)\\]]$/i);"
                "      if (m && m[1]) {"
                "        count = parseInt(m[1], 10) || 0;"
                "      } else if (loc.indexOf('mail.google') !== -1) {"
                "        var el = document.querySelector('a[href*=\"#inbox\"] .bsU, .nav-count');"
                "        if (el && el.textContent) {"
                "          var domNum = parseInt(el.textContent.trim(), 10);"
                "          if (!isNaN(domNum) && domNum >= 0) {"
                "            count = domNum;"
                "          }"
                "        }"
                "      }"
                "      if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.tabbedclient_unread) {"
                "        window.webkit.messageHandlers.tabbedclient_unread.postMessage(count);"
                "      }"
                "    } catch(err) {}"
                "  }"
                "  var __titleEl = document.querySelector('title');"
                "  if (__titleEl) {"
                "    try {"
                "      var __obs = new MutationObserver(__syncUnreadCount);"
                "      __obs.observe(__titleEl, { subtree: true, characterData: true, childList: true });"
                "    } catch(e) {}"
                "  }"
                "  document.addEventListener('DOMContentLoaded', __syncUnreadCount);"
                "  setInterval(__syncUnreadCount, 4000);"
                "  document.addEventListener('click', function(e) {"
                "    var isCtrlOrMiddle = (e.ctrlKey || e.metaKey || e.button === 1);"
                "    if (!isCtrlOrMiddle || e.button === 2) return;"
                "    var a = e.target.closest('a');"
                "    if (a && a.href && !a.href.startsWith('javascript:') && !a.href.startsWith('about:')) {"
                "      e.preventDefault();"
                "      e.stopPropagation();"
                "      if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.tabbedclient_bg_link) {"
                "        window.webkit.messageHandlers.tabbedclient_bg_link.postMessage(a.href);"
                "      }"
                "    }"
                "  }, true);"
                "  document.addEventListener('dragover', function(e) {"
                "    if (e.dataTransfer) {"
                "      var types = e.dataTransfer.types;"
                "      if (types && (types.includes('Files') || types.includes('text/uri-list') || types.includes('application/x-moz-file'))) {"
                "        e.dataTransfer.dropEffect = 'copy';"
                "      }"
                "    }"
                "  }, false);"
                "  document.addEventListener('click', function(e) {"
                "    var a = e.target.closest('a');"
                "    if (!a) return;"
                "    var href = a.getAttribute('href') || a.href || '';"
                "    var hasDownload = a.hasAttribute('download');"
                "    var isBlobOrData = href.startsWith('blob:') || href.startsWith('data:');"
                "    if (hasDownload || isBlobOrData) {"
                "      var filename = a.getAttribute('download') || a.download || '';"
                "      if (!filename && isBlobOrData) { filename = 'letoltes'; }"
                "      if (href.startsWith('blob:')) {"
                "        e.preventDefault();"
                "        e.stopPropagation();"
                "        fetch(href)"
                "          .then(function(res) {"
                "            var ct = res.headers.get('content-type') || '';"
                "            return res.blob().then(function(b) { return { blob: b, contentType: ct }; });"
                "          })"
                "          .then(function(info) {"
                "            var reader = new FileReader();"
                "            reader.onloadend = function() {"
                "              if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.tabbedclient_blob_download) {"
                "                window.webkit.messageHandlers.tabbedclient_blob_download.postMessage(JSON.stringify({"
                "                  filename: filename,"
                "                  dataUrl: reader.result,"
                "                  mimeType: info.contentType"
                "                }));"
                "              }"
                "            };"
                "            reader.readAsDataURL(info.blob);"
                "          })"
                "          .catch(function(err) {"
                "            console.error('[TabbedClient Blob Download Warning]', err);"
                "          });"
                "        return;"
                "      } else if (href.startsWith('data:')) {"
                "        e.preventDefault();"
                "        e.stopPropagation();"
                "        if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.tabbedclient_blob_download) {"
                "          window.webkit.messageHandlers.tabbedclient_blob_download.postMessage(JSON.stringify({"
                "            filename: filename,"
                "            dataUrl: href"
                "          }));"
                "        }"
                "        return;"
                "      }"
                "    }"
                "  }, true);"
                "})();"
            )
            user_script = WebKit2.UserScript.new(
                bg_and_dnd_script,
                WebKit2.UserContentInjectedFrames.ALL_FRAMES,
                WebKit2.UserScriptInjectionTime.START,
                None,
                None
            )
            ucm.add_script(user_script)
        except Exception as e:
            print(f"[Tab UserContentManager Init Warning] {e}", file=sys.stderr)

        # Letöltések közvetlen kezelése a WebView-n
        try:
            wv.connect("download-started", lambda w, d: self._on_download_started(None, d))
        except Exception:
            pass

        # Biztonságos jogosultságkezelés és értesítési híd
        wv.connect("permission-request", lambda w, r: self._on_permission_request(w, r, tab_id))
        wv.connect("show-notification", lambda w, n: self._on_show_notification(w, n, tab_id))
        wv.connect("notify::title", lambda w, p: self._on_tab_title_changed(w, p, tab_id))

        # Külső hivatkozások megnyitása külső böngészőben (pl. Gmail 'View in browser', e-mail linkek)
        wv.connect("decide-policy", lambda w, d, dt: self._on_decide_policy(w, d, dt, tab_id))
        wv.connect("create", lambda w, a: self._on_create_webview(w, a, tab_id))

        # Ablakbezárási védelem és renderelő folyamat stabilitás (Telegram téma / window.close védelem)
        try:
            wv.connect("close", lambda w: self._on_webview_close(w, tab_id))
        except Exception:
            pass
        try:
            wv.connect("web-process-terminated", lambda w, r: self._on_web_process_terminated(w, r, tab_id))
        except Exception:
            pass
        try:
            wv.connect("web-process-crashed", lambda w: self._on_web_process_crashed(w, tab_id))
        except Exception:
            pass

        container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        container.set_hexpand(True)
        container.set_vexpand(True)

        progress_bar = Gtk.ProgressBar()
        progress_bar.set_hexpand(True)
        progress_bar.set_fraction(0.15)
        progress_bar.set_no_show_all(True)
        progress_bar.show()

        def on_favicon_changed(view, param):
            try:
                surface = view.get_favicon()
                if surface is not None:
                    buf = io.BytesIO()
                    surface.write_to_png(buf)
                    b64 = base64.b64encode(buf.getvalue()).decode("ascii")
                    if b64:
                        self._update_tab_favicon(tab_id, favicon_data=f"data:image/png;base64,{b64}")
            except Exception:
                pass

        def on_dom_favicon_extracted(view, res, user_data):
            try:
                js_res = view.run_javascript_finish(res)
                val = js_res.get_js_value()
                if val and val.is_string():
                    href = val.to_string().strip()
                    if href.startswith("http://") or href.startswith("https://") or href.startswith("data:image/"):
                        self._update_tab_favicon(tab_id, favicon_url=href)
            except Exception:
                pass

        def on_tab_load_changed(view, event):
            if event == WebKit2.LoadEvent.STARTED:
                progress_bar.set_fraction(0.15)
                progress_bar.show()
            elif event == WebKit2.LoadEvent.COMMITTED:
                progress_bar.set_fraction(max(0.4, view.get_estimated_load_progress()))
                target_t = next((t for t in self.config.get("tabs", []) if t.get("id") == tab_id), None)
                if target_t:
                    z = float(target_t.get("zoomLevel", 1.0))
                    if abs(view.get_zoom_level() - z) > 0.001:
                        view.set_zoom_level(z)
            elif event == WebKit2.LoadEvent.FINISHED:
                progress_bar.hide()
                target_t = next((t for t in self.config.get("tabs", []) if t.get("id") == tab_id), None)
                if target_t:
                    z = float(target_t.get("zoomLevel", 1.0))
                    if abs(view.get_zoom_level() - z) > 0.001:
                        view.set_zoom_level(z)
                js_extract = (
                    "(function(){"
                    "var el=document.querySelector('link[rel*=\"icon\"]');"
                    "return (el&&el.href)?el.href:(location.origin+'/favicon.ico');"
                    "})();"
                )
                view.run_javascript(js_extract, None, on_dom_favicon_extracted, None)

        def on_tab_progress(view, param):
            p = view.get_estimated_load_progress()
            if 0.0 < p < 1.0:
                progress_bar.set_fraction(max(0.1, p))
                progress_bar.show()
            elif p >= 1.0:
                progress_bar.hide()

        wv.connect("notify::favicon", on_favicon_changed)
        wv.connect("load-changed", on_tab_load_changed)
        wv.connect("notify::estimated-load-progress", on_tab_progress)

        container.pack_start(progress_bar, False, False, 0)
        container.pack_start(wv, True, True, 0)

        self.webviews[tab_id] = container
        self.tab_webviews[tab_id] = wv
        self.stack.add_named(container, tab_id)
        container.show_all()
        progress_bar.show()
        wv.load_uri(url)

    def _create_icon_menu_item(self, icon_name: str, label_text: str) -> Gtk.MenuItem:
        item = Gtk.MenuItem()
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.MENU)
        label = Gtk.Label(label=label_text, xalign=0.0)
        box.pack_start(icon, False, False, 0)
        box.pack_start(label, True, True, 0)
        item.add(box)
        return item

    def reload_tab(self, tab_id: str):
        if not tab_id or tab_id == "home":
            tab_id = self.config.get("activeTabId")
        if not tab_id or tab_id == "home":
            return
        if self.config.get("activeTabId") != tab_id:
            self.switch_to_tab(tab_id)
        wv = self.tab_webviews.get(tab_id)
        if wv is not None:
            wv.reload()

    def reset_tab_to_initial_url(self, tab_id: str):
        if not tab_id or tab_id == "home":
            tab_id = self.config.get("activeTabId")
        if not tab_id or tab_id == "home":
            return
        if self.config.get("activeTabId") != tab_id:
            self.switch_to_tab(tab_id)
        target_tab = next((t for t in self.config.get("tabs", []) if t.get("id") == tab_id), None)
        if not target_tab:
            return
        initial_url = target_tab.get("url")
        if not initial_url:
            return
        wv = self.tab_webviews.get(tab_id)
        if wv is not None:
            wv.load_uri(initial_url)

    def toggle_tab_notifications(self, tab_id: str):
        tabs = self.config.get("tabs", [])
        tab = next((t for t in tabs if t.get("id") == tab_id), None)
        if tab:
            tab["notificationsEnabled"] = not tab.get("notificationsEnabled", True)
            save_config(self.config)
            self.sync_all_views()

    def move_tab(self, tab_id: str, direction: int):
        tabs = self.config.get("tabs", [])
        idx = next((i for i, t in enumerate(tabs) if t.get("id") == tab_id), -1)
        if idx == -1:
            return
        new_idx = idx + direction
        if 0 <= new_idx < len(tabs):
            tabs[idx], tabs[new_idx] = tabs[new_idx], tabs[idx]
            for i, t in enumerate(tabs):
                t["order"] = i
            save_config(self.config)
            self.sync_all_views()

    def show_sidebar_context_menu(self, tab_id: str):
        target_service_id = tab_id if (tab_id and tab_id != "home") else self.config.get("activeTabId")
        has_service = bool(
            target_service_id
            and any(t.get("id") == target_service_id for t in self.config.get("tabs", []))
        )
        target_tab = next((t for t in self.config.get("tabs", []) if t.get("id") == target_service_id), None) if has_service else None

        menu = Gtk.Menu()
        self._context_menu = menu

        item_home = self._create_icon_menu_item("go-home-symbolic", "Kezdőlap")
        item_home.connect("activate", lambda *_: self.switch_to_tab("home"))
        menu.append(item_home)

        item_reset = self._create_icon_menu_item("document-revert-symbolic", "Visszatérés a kezdőoldalra")
        item_reset.set_sensitive(has_service)
        item_reset.connect("activate", lambda *_: self.reset_tab_to_initial_url(target_service_id))
        menu.append(item_reset)

        item_reload = self._create_icon_menu_item("view-refresh-symbolic", "Frissítés")
        item_reload.set_sensitive(has_service)
        item_reload.connect("activate", lambda *_: self.reload_tab(target_service_id))
        menu.append(item_reload)

        if has_service and target_tab:
            # Értesítések némítása / feloldása
            is_muted = not target_tab.get("notificationsEnabled", True)
            mute_icon = "audio-volume-high-symbolic" if is_muted else "audio-volume-muted-symbolic"
            mute_text = "Értesítések engedélyezése" if is_muted else "Értesítések némítása"
            item_mute = self._create_icon_menu_item(mute_icon, mute_text)
            item_mute.connect("activate", lambda *_: self.toggle_tab_notifications(target_service_id))
            menu.append(item_mute)

            # Mozgatás fel / le
            tabs = self.config.get("tabs", [])
            idx = next((i for i, t in enumerate(tabs) if t.get("id") == target_service_id), -1)

            item_up = self._create_icon_menu_item("go-up-symbolic", "Mozgatás feljebb")
            item_up.set_sensitive(idx > 0)
            item_up.connect("activate", lambda *_: self.move_tab(target_service_id, -1))
            menu.append(item_up)

            item_down = self._create_icon_menu_item("go-down-symbolic", "Mozgatás lejjebb")
            item_down.set_sensitive(idx >= 0 and idx < len(tabs) - 1)
            item_down.connect("activate", lambda *_: self.move_tab(target_service_id, 1))
            menu.append(item_down)

        menu.append(Gtk.SeparatorMenuItem())

        item_delete = self._create_icon_menu_item("user-trash-symbolic", "Szolgáltatás törlése")
        item_delete.set_sensitive(has_service)
        item_delete.connect("activate", lambda *_: self._delete_tab_by_id(target_service_id))
        menu.append(item_delete)

        menu.show_all()
        if self._last_button_event is not None:
            menu.popup_at_pointer(self._last_button_event)
        else:
            menu.popup(None, None, None, None, 3, Gtk.get_current_event_time())

    def _delete_tab_by_id(self, tab_id: str):
        if not tab_id:
            return
        target_tab = next((t for t in self.config.get("tabs", []) if t.get("id") == tab_id), None)
        if not target_tab:
            return

        title = target_tab.get("title") or target_tab.get("name") or "Szolgáltatás"
        url = target_tab.get("url", "")

        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.NONE,
            text=f"Biztosan törölni szeretnéd a(z) „{title}” szolgáltatást?"
        )
        dialog.format_secondary_text(
            f"Webcím: {url}\nA szolgáltatás fül eltávolításra kerül a listából."
        )
        dialog.add_button("Mégse", Gtk.ResponseType.CANCEL)
        del_btn = dialog.add_button("Törlés", Gtk.ResponseType.OK)
        try:
            del_btn.get_style_context().add_class("destructive-action")
        except Exception:
            pass
        dialog.set_default_response(Gtk.ResponseType.CANCEL)

        response = dialog.run()
        dialog.destroy()
        if response != Gtk.ResponseType.OK:
            return

        self.config["tabs"] = [t for t in self.config["tabs"] if t["id"] != tab_id]
        self.tab_webviews.pop(tab_id, None)
        if tab_id in self.webviews:
            widget = self.webviews.pop(tab_id)
            self.stack.remove(widget)
            widget.destroy()

        if self.previous_tab_id == tab_id:
            self.previous_tab_id = None

        if self.config.get("activeTabId") == tab_id:
            remaining = self.config["tabs"]
            if remaining:
                self.switch_to_tab(remaining[0]["id"])
            else:
                self.switch_to_tab("home")
        else:
            save_config(self.config)
            self.sync_all_views()

    def sync_all_views(self):
        collapsed = bool(self.config.get("sidebarCollapsed", False))
        self._apply_sidebar_width(collapsed)

        normalized_tabs = []
        for idx, t in enumerate(self.config.get("tabs", [])):
            title = t.get("title") or t.get("name") or "Szolgáltatás"
            profile = t.get("profile") or t.get("profileId") or "default"
            url = t.get("url", "https://example.com")
            notifications_enabled = bool(t.get("notificationsEnabled", True))
            unread_count = int(t.get("unreadCount", 0))
            order = int(t.get("order", idx))
            zoom_lvl = float(t.get("zoomLevel", 1.0))
            if zoom_lvl < 0.25 or zoom_lvl > 5.0:
                zoom_lvl = 1.0

            icon_resolved = resolve_service_icon(title, url, t.get("icon", ""))
            fav_clean = "" if icon_resolved != "globe" else (t.get("favicon") or "")
            fav_url_clean = _default_favicon_url(url) if icon_resolved != "globe" else (t.get("faviconUrl") or _default_favicon_url(url))
            if icon_resolved == "calendar":
                unread_count = 0

            normalized_tabs.append({
                "id": t.get("id"),
                "title": title,
                "name": title,
                "url": url,
                "icon": icon_resolved,
                "profile": profile,
                "profileId": profile,
                "notificationsEnabled": notifications_enabled,
                "unreadCount": unread_count,
                "order": order,
                "favicon": fav_clean,
                "faviconUrl": fav_url_clean,
                "zoomLevel": round(zoom_lvl, 2)
            })
        self.config["tabs"] = normalized_tabs

        settings = self.config.get("settings", {})
        payload = {
            "version": APP_VERSION,
            "theme": self.config.get("theme", "slate"),
            "sidebarCollapsed": collapsed,
            "activeTabId": self.config.get("activeTabId") or "home",
            "tabs": normalized_tabs,
            "profiles": self.config.get("profiles", []),
            "view": self.current_welcome_view,
            "settings": {
                "theme": self.config.get("theme", "slate"),
                "sidebarCollapsed": collapsed,
                "minimizeToTrayOnClose": settings.get("minimizeToTrayOnClose", True),
                "startMinimized": settings.get("startMinimized", False),
                "hardwareAcceleration": settings.get("hardwareAcceleration", True)
            }
        }
        js_arg = json.dumps(payload, ensure_ascii=False)
        self.sidebar_webview.run_javascript(f"if (window.syncFromBackend) window.syncFromBackend({js_arg});", None, None, None)
        self.welcome_webview.run_javascript(f"if (window.syncFromBackend) window.syncFromBackend({js_arg});", None, None, None)
        self.update_tray_menu()

    def switch_to_tab(self, tab_id: str):
        self._flush_config_save()
        if not tab_id or tab_id == "home":
            self.config["activeTabId"] = None
            self.current_welcome_view = "dashboard"
            save_config(self.config)
            self.stack.set_visible_child_name("welcome")
            self.set_title("TabbedClient — Kezdőlap")
            self.sync_all_views()
            return

        target_tab = next((t for t in self.config["tabs"] if t["id"] == tab_id), None)
        if not target_tab:
            return

        wv = self.tab_webviews.get(tab_id)
        current_title = wv.get_title() if wv else ""
        if extract_unread_count(current_title, target_tab.get("url", "")) == 0:
            target_tab["unreadCount"] = 0

        self._ensure_tab_webview(target_tab)
        wv = self.tab_webviews.get(tab_id)
        if wv:
            saved_zoom = float(target_tab.get("zoomLevel", 1.0))
            if abs(wv.get_zoom_level() - saved_zoom) > 0.001:
                wv.set_zoom_level(saved_zoom)
            wv.grab_focus()

        self.config["activeTabId"] = tab_id
        self.previous_tab_id = tab_id
        save_config(self.config)

        self.stack.set_visible_child_name(tab_id)
        self.stack.show_all()
        title = target_tab.get("title") or target_tab.get("name") or "Szolgáltatás"
        self.set_title(f"{title} — TabbedClient")
        self.sync_all_views()

    def show_welcome_modal(self, view_name: str):
        current_active = self.config.get("activeTabId")
        if current_active and current_active != "home":
            self.previous_tab_id = current_active
        self.current_welcome_view = view_name
        self.config["activeTabId"] = None
        self.stack.set_visible_child_name("welcome")
        self.stack.show_all()
        if view_name == "settings":
            self.set_title("Beállítások — TabbedClient")
        elif view_name == "add-tab":
            self.set_title("Új szolgáltatás felvétele — TabbedClient")
        else:
            self.set_title("TabbedClient — Kezdőlap")
        self.sync_all_views()

    def cancel_welcome_modal(self):
        tabs = self.config.get("tabs", [])
        if self.previous_tab_id and any(t["id"] == self.previous_tab_id for t in tabs):
            target = self.previous_tab_id
            self.previous_tab_id = None
            self.switch_to_tab(target)
        else:
            self.switch_to_tab("home")

    def parse_js_message(self, js_result):
        val = js_result.get_js_value()
        if val.is_string():
            raw = val.to_string()
        else:
            raw = val.to_json(0)
        return json.loads(raw)

    def on_script_message(self, content_manager, js_result):
        try:
            msg = self.parse_js_message(js_result)
        except Exception as e:
            print(f"[IPC Error] {e}", file=sys.stderr)
            return

        msg_type = msg.get("type")

        if msg_type in ("SIDEBAR_READY", "WELCOME_READY"):
            self.sync_all_views()

        elif msg_type == "SET_COLLAPSED":
            collapsed = bool(msg.get("collapsed", False))
            self.config["sidebarCollapsed"] = collapsed
            self.config.setdefault("settings", {})["sidebarCollapsed"] = collapsed
            save_config(self.config)
            self._apply_sidebar_width(collapsed)
            self.sync_all_views()

        elif msg_type == "SET_THEME":
            theme = msg.get("theme", "slate")
            if theme in VALID_THEMES:
                self.config["theme"] = theme
                self.config.setdefault("settings", {})["theme"] = theme
                save_config(self.config)
                self.sync_all_views()

        elif msg_type == "SET_SETTINGS":
            settings = msg.get("settings", {})
            if isinstance(settings, dict):
                self.config.setdefault("settings", {}).update(settings)
                if "theme" in settings and settings["theme"] in VALID_THEMES:
                    self.config["theme"] = settings["theme"]
                if "sidebarCollapsed" in settings:
                    self.config["sidebarCollapsed"] = bool(settings["sidebarCollapsed"])
                save_config(self.config)
                self.sync_all_views()

        elif msg_type == "OPEN_ADD_TAB":
            self.show_welcome_modal("add-tab")

        elif msg_type == "OPEN_SETTINGS":
            self.show_welcome_modal("settings")

        elif msg_type == "CANCEL_MODAL":
            self.cancel_welcome_modal()

        elif msg_type == "SWITCH_TAB":
            tab_id = msg.get("id") or msg.get("tabId")
            self.switch_to_tab(tab_id)

        elif msg_type == "RELOAD_TAB":
            tab_id = msg.get("id") or msg.get("tabId")
            self.reload_tab(tab_id)

        elif msg_type == "RESET_TAB_URL":
            tab_id = msg.get("id") or msg.get("tabId")
            self.reset_tab_to_initial_url(tab_id)

        elif msg_type == "SHOW_CONTEXT_MENU":
            tab_id = msg.get("id") or msg.get("tabId")
            self.show_sidebar_context_menu(tab_id)

        elif msg_type == "TOGGLE_MUTE":
            tab_id = msg.get("id") or msg.get("tabId")
            self.toggle_tab_notifications(tab_id)

        elif msg_type == "MOVE_TAB":
            tab_id = msg.get("id") or msg.get("tabId")
            direction = int(msg.get("direction", 0))
            if direction != 0:
                self.move_tab(tab_id, direction)

        elif msg_type == "ADD_TAB":
            tab_obj = msg.get("tab") if isinstance(msg.get("tab"), dict) else msg
            title = (tab_obj.get("title") or tab_obj.get("name") or "Új szolgáltatás").strip()
            profile = tab_obj.get("profile") or tab_obj.get("profileId") or "work"
            url = (tab_obj.get("url") or "https://example.com").strip()
            icon = resolve_service_icon(title, url, tab_obj.get("icon", ""))
            new_tab = {
                "id": f"tab-{uuid.uuid4().hex[:8]}",
                "title": title,
                "name": title,
                "url": url,
                "icon": icon,
                "profile": profile,
                "profileId": profile,
                "notificationsEnabled": True,
                "unreadCount": 0,
                "order": len(self.config.get("tabs", [])),
                "favicon": "",
                "faviconUrl": _default_favicon_url(url),
                "zoomLevel": 1.0
            }
            self.config.setdefault("tabs", []).append(new_tab)
            save_config(self.config)
            self.switch_to_tab(new_tab["id"])

        elif msg_type == "DELETE_TAB":
            tab_id = msg.get("id") or msg.get("tabId")
            self._delete_tab_by_id(tab_id)


def main():
    GLib.set_prgname("tabbedclient")
    GLib.set_application_name("TabbedClient")

    # Egypéldányos ellenőrzés: ha már fut példány, aktiváljuk és ez a folyamat kilép
    if try_activate_existing_instance():
        sys.exit(0)

    win = TabbedClientWindow()

    def _on_activate_remote():
        win.restore_and_present()

    def _on_quit_remote():
        win.quit_application()

    server = setup_single_instance_server(_on_activate_remote, _on_quit_remote)

    Gtk.main()


if __name__ == "__main__":
    main()
