TabbedClient — Hordozható Windows Csomag
========================================

Indítás Windows alatt:
1. Kattints duplán a TabbedClient.vbs fájlra (csendes indítás, fekete parancssor nélkül).
VAGY:
2. Kattints duplán a TabbedClient.bat fájlra.

Működés:
- Ha telepítve van a Python (3.9+), a program közvetlenül fut.
- Ha nincs Python, automatikusan a Windows beépített Microsoft Edge App Mode böngészőjét indítja el külön elszeparált adatprofilokkal.
- Semmilyen telepítés vagy rendszergazdai jogosultság nem szükséges!
